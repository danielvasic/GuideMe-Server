-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2015 at 12:56 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `guideme`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
`id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `place_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `description`, `content`, `place_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Praesent id massa id nisl venenatis lacinia.', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.\n\nNullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.\n\nMorbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 57, 6, 3, '2015-01-17 08:35:53', '2015-01-15 07:27:50', NULL),
(2, 'Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 'Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.\n\nIn congue. Etiam justo. Etiam pretium iaculis justo.\n\nIn hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', NULL, 4, 3, '2015-01-14 22:14:12', '2015-01-06 13:22:04', NULL),
(3, 'Donec semper sapien a libero.', 'Donec quis orci eget orci vehicula condimentum.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.\n\nSed ante. Vivamus tortor. Duis mattis egestas metus.', 11, 3, 5, '2015-01-09 18:48:48', '2015-01-05 03:42:12', NULL),
(4, 'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.', NULL, 66, 8, 2, '2015-01-14 18:27:05', '2015-01-20 04:44:25', NULL),
(5, 'Etiam faucibus cursus urna.', 'Aenean lectus. Pellentesque eget nunc.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.\n\nEtiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.\n\nPraesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.', 15, 4, 6, '2015-01-07 05:53:30', '2015-01-23 18:27:32', NULL),
(6, 'Quisque id justo sit amet sapien dignissim vestibulum.', 'Vivamus tortor. Duis mattis egestas metus. Aenean fermentum.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', 58, 6, 5, '2015-01-28 18:20:40', '2015-01-17 22:23:28', NULL),
(7, 'Integer ac leo.', 'Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.\n\nQuisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 36, 2, 7, '2015-01-02 02:12:03', '2015-01-01 18:14:11', NULL),
(8, 'Suspendisse ornare consequat lectus.', 'Morbi a ipsum. Integer a nibh. In quis justo.', NULL, NULL, 4, 6, '2015-01-30 11:11:14', '2015-01-21 19:51:00', NULL),
(9, 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.\n\nCras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.\n\nQuisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 98, 6, 6, '2015-01-30 06:10:13', '2015-01-26 02:54:04', NULL),
(10, 'Aliquam quis turpis eget elit sodales scelerisque.', 'Aenean fermentum.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.\n\nNullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 95, 8, 5, '2015-01-01 05:20:09', '2015-01-23 14:17:29', NULL),
(11, 'Suspendisse potenti.', 'Vivamus vestibulum sagittis sapien.', NULL, 66, 2, 5, '2015-01-21 05:39:45', '2015-01-29 16:49:11', NULL),
(12, 'Suspendisse potenti.', NULL, 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.\n\nSed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.\n\nPellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 9, 4, 6, '2015-01-08 08:32:23', '2015-01-27 09:53:04', NULL),
(13, 'Morbi non quam nec dui luctus rutrum.', 'Aliquam erat volutpat. In congue.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.\n\nIn quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.\n\nMaecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 70, 2, 4, '2015-01-10 08:41:00', '2015-01-16 05:40:00', NULL),
(14, 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem. Sed sagittis.', NULL, 24, 2, 8, '2015-01-12 01:36:14', '2015-01-07 03:46:30', NULL),
(15, 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.\n\nVestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.\n\nDuis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.', 61, 6, 8, '2015-01-31 04:34:44', '2015-01-15 18:01:33', NULL),
(16, 'Pellentesque eget nunc.', 'Vivamus vel nulla eget eros elementum pellentesque.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.\n\nQuisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.\n\nVestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', NULL, 7, 8, '2015-01-31 17:51:30', '2015-01-08 22:10:47', NULL),
(17, 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.\n\nDuis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 65, 1, 6, '2015-01-03 00:23:23', '2015-01-08 09:33:22', NULL),
(18, 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', 'Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.\n\nInteger tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.\n\nPraesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 96, 7, 6, '2015-01-04 11:57:23', '2015-01-20 19:53:17', NULL),
(19, 'Nulla justo.', 'Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius.', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 92, 2, 8, '2015-01-25 14:56:53', '2015-01-22 06:01:53', NULL),
(20, 'Vivamus tortor.', 'Pellentesque eget nunc.', NULL, 12, 7, 3, '2015-01-05 14:44:58', '2015-01-28 02:57:18', NULL),
(21, 'Donec vitae nisi.', 'Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.', 76, 4, 4, '2015-01-13 19:35:38', '2015-01-19 20:28:08', NULL),
(22, 'Suspendisse potenti.', 'Praesent blandit. Nam nulla.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.\n\nIn quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 18, 1, 1, '2015-01-10 00:33:54', '2015-01-24 03:15:23', NULL),
(23, 'Ut tellus.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 86, 2, 6, '2015-01-12 11:17:49', '2015-01-23 21:40:47', NULL),
(24, 'Nunc rhoncus dui vel sem.', 'Maecenas pulvinar lobortis est. Phasellus sit amet erat.', 'Fusce consequat. Nulla nisl. Nunc nisl.', 64, 3, 5, '2015-01-10 12:39:32', '2015-01-28 05:55:36', NULL),
(25, 'Cras non velit nec nisi vulputate nonummy.', 'Aenean sit amet justo. Morbi ut odio. Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.\n\nEtiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', 78, 5, 5, '2015-01-21 14:57:58', '2015-01-27 18:12:28', NULL),
(26, 'Nullam porttitor lacus at turpis.', 'In congue. Etiam justo.', 'Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.\n\nMorbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 47, 3, 7, '2015-01-12 11:06:31', '2015-01-15 19:25:34', NULL),
(27, 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'In eleifend quam a odio.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 70, 5, 4, '2015-01-24 01:30:19', '2015-01-22 01:13:05', NULL),
(28, 'Suspendisse ornare consequat lectus.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.\n\nAenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.\n\nQuisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 4, 6, 4, '2015-01-09 15:34:56', '2015-01-03 08:27:40', NULL),
(29, 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Donec quis orci eget orci vehicula condimentum. Curabitur in libero ut massa volutpat convallis.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 9, 2, 7, '2015-01-23 11:54:10', '2015-01-11 20:33:42', NULL),
(30, 'Suspendisse potenti.', 'Quisque porta volutpat erat.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.\n\nAenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.\n\nQuisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 19, 3, 6, '2015-01-22 11:40:23', '2015-01-02 08:59:57', NULL),
(31, 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.\n\nSed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.\n\nPellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 82, 4, 3, '2015-01-15 18:21:23', '2015-01-12 00:57:25', NULL),
(32, 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.\n\nIn sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 39, 8, 8, '2015-01-20 11:45:07', '2015-01-18 23:59:03', NULL),
(33, 'In hac habitasse platea dictumst.', 'Ut tellus.', 'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.\n\nVestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.\n\nIn congue. Etiam justo. Etiam pretium iaculis justo.', NULL, 2, 4, '2015-01-24 10:49:46', '2015-01-26 20:34:40', NULL),
(34, 'Curabitur at ipsum ac tellus semper interdum.', 'Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', 46, 6, 3, '2015-01-13 03:24:30', '2015-01-05 09:58:22', NULL),
(35, 'Nulla facilisi.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.\n\nDuis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 58, 2, 4, '2015-01-14 05:52:43', '2015-01-29 01:47:21', NULL),
(36, 'Ut at dolor quis odio consequat varius.', 'Cras in purus eu magna vulputate luctus.', NULL, 99, 6, 6, '2015-01-19 04:46:33', '2015-01-03 17:37:51', NULL),
(37, 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Donec vitae nisi. Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.\n\nDuis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.', 42, 6, 4, '2015-01-06 08:43:42', '2015-01-07 02:54:49', NULL),
(38, 'Suspendisse potenti.', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 68, 1, 6, '2015-01-03 19:54:54', '2015-01-14 06:35:08', NULL),
(39, 'Suspendisse potenti.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue.', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 95, 8, 7, '2015-01-05 19:13:03', '2015-01-28 04:02:49', NULL),
(40, 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est. Phasellus sit amet erat.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.\n\nIn sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 65, 8, 3, '2015-01-23 11:18:01', '2015-01-31 12:34:45', NULL),
(41, 'Morbi porttitor lorem id ligula.', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem. Duis aliquam convallis nunc.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.\n\nCras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 67, 8, 1, '2015-01-03 00:12:15', '2015-01-24 07:12:14', NULL),
(42, 'Pellentesque ultrices mattis odio.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 20, 4, 6, '2015-01-27 12:23:45', '2015-01-09 22:22:10', NULL),
(43, 'Aliquam erat volutpat.', NULL, 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.\n\nCras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 25, 3, 6, '2015-01-22 07:45:41', '2015-01-29 01:13:49', NULL),
(44, 'Nullam varius.', 'Suspendisse potenti. Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.\n\nVestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', 85, 3, 4, '2015-01-14 18:42:44', '2015-01-06 14:02:22', NULL),
(45, 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.\n\nMaecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.\n\nNullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 17, 6, 7, '2015-01-01 13:59:10', '2015-01-05 03:22:01', NULL),
(46, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue.', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 5, 4, 5, '2015-01-16 15:42:33', '2015-01-04 03:56:25', NULL),
(47, 'Nulla tellus.', 'Integer ac neque.', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', NULL, 2, 3, '2015-01-24 09:49:41', '2015-01-13 14:08:15', NULL),
(48, 'Vestibulum rutrum rutrum neque.', 'Donec ut dolor.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 88, 7, 6, '2015-01-19 07:43:00', '2015-01-21 09:41:26', NULL),
(49, 'Phasellus sit amet erat.', 'In hac habitasse platea dictumst.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.\n\nNulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.\n\nCras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 1, 6, 3, '2015-01-09 12:58:12', '2015-01-23 17:59:41', NULL),
(50, 'Nulla nisl.', 'Nam nulla.', NULL, 85, 5, 6, '2015-01-23 06:15:35', '2015-01-30 01:48:22', NULL),
(51, 'Integer ac leo.', 'Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.\n\nNam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 4, 1, 4, '2015-01-21 14:23:59', '2015-01-01 01:58:34', NULL),
(52, 'Quisque id justo sit amet sapien dignissim vestibulum.', 'Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat.', 'Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.\n\nPhasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.\n\nProin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 14, 3, 3, '2015-01-30 22:48:23', '2015-01-04 11:57:12', NULL),
(53, 'Donec vitae nisi.', 'Aliquam erat volutpat. In congue. Etiam justo.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 20, 4, 6, '2015-01-23 16:17:51', '2015-01-07 16:25:58', NULL),
(54, 'Integer ac neque.', 'Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.\n\nProin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.\n\nAenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 87, 5, 1, '2015-01-30 00:48:52', '2015-01-09 05:15:21', NULL),
(55, 'Duis mattis egestas metus.', 'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', NULL, 95, 3, 8, '2015-01-15 19:36:48', '2015-01-09 21:20:56', NULL),
(56, 'Aenean auctor gravida sem.', 'Nulla tellus. In sagittis dui vel nisl. Duis ac nibh.', 'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', NULL, 8, 7, '2015-01-25 02:15:05', '2015-01-07 09:37:24', NULL),
(57, 'Quisque id justo sit amet sapien dignissim vestibulum.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio.', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.\n\nNam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 60, 4, 6, '2015-01-24 16:36:03', '2015-01-26 13:59:04', NULL),
(58, 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Donec vitae nisi.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 8, 2, 1, '2015-01-26 06:41:49', '2015-01-14 07:24:32', NULL),
(59, 'Nullam porttitor lacus at turpis.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue. Vestibulum rutrum rutrum neque.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 96, 8, 7, '2015-01-05 16:11:52', '2015-01-28 17:14:24', NULL),
(60, 'Etiam faucibus cursus urna.', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Phasellus in felis. Donec semper sapien a libero. Nam dui.\n\nProin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.\n\nInteger ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 54, 3, 6, '2015-01-04 01:47:36', '2015-01-03 20:19:07', NULL),
(61, 'Duis ac nibh.', 'Quisque id justo sit amet sapien dignissim vestibulum.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', NULL, 3, 4, '2015-01-18 22:46:57', '2015-01-03 16:04:00', NULL),
(62, 'Donec posuere metus vitae ipsum.', NULL, 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.\n\nInteger ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.\n\nNam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 36, 3, 6, '2015-01-02 09:59:08', '2015-01-03 11:47:43', NULL),
(63, 'Etiam vel augue.', NULL, 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.\n\nInteger tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 60, 3, 4, '2015-01-15 09:05:16', '2015-01-16 07:04:58', NULL),
(64, 'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Pellentesque at nulla. Suspendisse potenti.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.\n\nInteger tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.\n\nPraesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 96, 8, 1, '2015-01-29 12:33:17', '2015-01-23 05:14:51', NULL),
(65, 'Etiam pretium iaculis justo.', NULL, NULL, 76, 5, 6, '2015-01-31 08:11:34', '2015-01-09 09:57:13', NULL),
(66, 'Ut at dolor quis odio consequat varius.', 'Duis consequat dui nec nisi volutpat eleifend.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.\n\nPraesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.\n\nMorbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', NULL, 6, 6, '2015-01-20 14:31:56', '2015-01-24 12:55:50', NULL),
(67, 'Nulla ut erat id mauris vulputate elementum.', 'Aliquam erat volutpat. In congue. Etiam justo.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.\n\nIn quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 2, 5, 6, '2015-01-10 10:21:10', '2015-01-07 14:05:50', NULL),
(68, 'Nam tristique tortor eu pede.', 'Proin eu mi.', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.\n\nPhasellus in felis. Donec semper sapien a libero. Nam dui.\n\nProin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.', 34, 1, 1, '2015-01-23 16:41:50', '2015-01-04 05:15:47', NULL),
(69, 'Morbi quis tortor id nulla ultrices aliquet.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', NULL, 4, 6, '2015-01-09 00:27:56', '2015-01-29 17:28:46', NULL),
(70, 'Curabitur convallis.', 'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.\n\nFusce consequat. Nulla nisl. Nunc nisl.\n\nDuis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', NULL, 6, 2, '2015-01-08 01:58:48', '2015-01-18 03:27:23', NULL),
(71, 'Suspendisse accumsan tortor quis turpis.', 'Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.\n\nDuis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.\n\nIn sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', NULL, 5, 1, '2015-01-03 23:21:13', '2015-01-29 06:08:31', NULL),
(72, 'Quisque porta volutpat erat.', 'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo.', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.\n\nPraesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.\n\nCras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 38, 2, 3, '2015-01-08 04:44:08', '2015-01-03 11:46:09', NULL),
(73, 'Nulla facilisi.', 'Aenean lectus.', 'Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 26, 5, 8, '2015-01-06 04:07:28', '2015-01-20 10:15:45', NULL),
(74, 'Morbi non quam nec dui luctus rutrum.', 'Pellentesque ultrices mattis odio. Donec vitae nisi.', NULL, 43, 4, 5, '2015-01-28 15:57:30', '2015-01-25 04:50:02', NULL),
(75, 'In hac habitasse platea dictumst.', 'In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin interdum mauris non ligula pellentesque ultrices.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.\n\nCurabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 21, 1, 7, '2015-01-21 06:08:06', '2015-01-27 04:37:19', NULL),
(76, 'Duis aliquam convallis nunc.', 'Pellentesque at nulla. Suspendisse potenti.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.\n\nAenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 71, 3, 8, '2015-01-13 10:26:47', '2015-01-01 16:01:15', NULL),
(77, 'Vestibulum rutrum rutrum neque.', 'Donec quis orci eget orci vehicula condimentum.', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 43, 5, 4, '2015-01-24 20:20:22', '2015-01-29 03:54:22', NULL),
(78, 'In congue.', 'Nulla facilisi. Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.\n\nMaecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.\n\nNullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 85, 7, 6, '2015-01-23 15:22:16', '2015-01-28 06:16:57', NULL),
(79, 'Integer non velit.', 'Vivamus in felis eu sapien cursus vestibulum.', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.\n\nMauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', 29, 7, 5, '2015-01-24 16:17:27', '2015-01-13 05:45:06', NULL),
(80, 'Duis bibendum.', 'Nulla tellus. In sagittis dui vel nisl.', 'In congue. Etiam justo. Etiam pretium iaculis justo.\n\nIn hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 57, 2, 7, '2015-01-06 17:31:12', '2015-01-22 04:57:00', NULL),
(81, 'Vivamus in felis eu sapien cursus vestibulum.', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti. In eleifend quam a odio.', 'Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.\n\nMaecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.\n\nCurabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 62, 1, 2, '2015-01-28 18:54:20', '2015-01-12 13:22:18', NULL),
(82, 'Nunc rhoncus dui vel sem.', NULL, 'Fusce consequat. Nulla nisl. Nunc nisl.\n\nDuis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 75, 3, 7, '2015-01-07 03:55:44', '2015-01-12 05:55:52', NULL),
(83, 'Nulla justo.', 'Phasellus in felis. Donec semper sapien a libero.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.\n\nFusce consequat. Nulla nisl. Nunc nisl.', 70, 1, 4, '2015-01-29 04:30:51', '2015-01-20 00:53:02', NULL),
(84, 'Praesent blandit.', 'Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 17, 3, 4, '2015-01-24 02:27:21', '2015-01-18 08:41:51', NULL),
(85, 'Pellentesque ultrices mattis odio.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.\n\nIn hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 72, 4, 5, '2015-01-06 13:55:53', '2015-01-07 19:02:54', NULL),
(86, 'Duis aliquam convallis nunc.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 'Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.\n\nDuis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', 99, 4, 5, '2015-01-19 00:58:36', '2015-01-20 20:36:33', NULL),
(87, 'Duis bibendum.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.\n\nIn sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.\n\nSuspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', NULL, 4, 5, '2015-01-22 16:28:16', '2015-01-06 05:35:39', NULL),
(88, 'Suspendisse accumsan tortor quis turpis.', 'Integer tincidunt ante vel ipsum.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.\n\nIn sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.\n\nSuspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 71, 5, 7, '2015-01-05 10:31:11', '2015-01-14 17:16:57', NULL),
(89, 'In hac habitasse platea dictumst.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 67, 4, 5, '2015-01-20 11:10:25', '2015-01-14 08:08:49', NULL),
(90, 'Aliquam sit amet diam in magna bibendum imperdiet.', 'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 'Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.\n\nDuis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', 15, 8, 6, '2015-01-28 15:03:22', '2015-01-28 21:19:45', NULL),
(91, 'Pellentesque at nulla.', NULL, 'Fusce consequat. Nulla nisl. Nunc nisl.\n\nDuis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.\n\nIn hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 47, 4, 5, '2015-01-26 15:10:57', '2015-01-02 02:35:21', NULL),
(92, 'Etiam vel augue.', 'Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', NULL, 1, 1, '2015-01-18 15:31:03', '2015-01-28 03:53:58', NULL),
(93, 'Integer tincidunt ante vel ipsum.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti. Nullam porttitor lacus at turpis.', 'Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.\n\nCras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 99, 4, 7, '2015-01-01 04:21:01', '2015-01-25 02:29:48', NULL),
(94, 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'Morbi a ipsum. Integer a nibh.', 'Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.\n\nCras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 6, 6, 5, '2015-01-27 05:36:16', '2015-01-17 23:02:16', NULL),
(95, 'In hac habitasse platea dictumst.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', 44, 3, 6, '2015-01-25 14:56:05', '2015-01-28 08:56:58', NULL),
(96, 'Maecenas rhoncus aliquam lacus.', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 28, 5, 6, '2015-01-12 20:48:23', '2015-01-08 13:57:27', NULL),
(97, 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Nullam molestie nibh in lectus. Pellentesque at nulla. Suspendisse potenti.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 72, 6, 1, '2015-01-23 09:24:00', '2015-01-19 10:27:03', NULL),
(98, 'Morbi porttitor lorem id ligula.', NULL, 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.\n\nInteger ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.\n\nNam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 34, 7, 4, '2015-01-18 19:03:12', '2015-01-27 12:42:02', NULL),
(99, 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Morbi a ipsum.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.\n\nIn quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 16, 3, 5, '2015-01-09 09:54:52', '2015-01-19 23:04:16', NULL),
(100, 'Maecenas tincidunt lacus at velit.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 'Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.\n\nMaecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.\n\nCurabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 83, 2, 6, '2015-01-07 09:52:04', '2015-01-27 03:53:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE IF NOT EXISTS `audio` (
`id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `audio`
--

INSERT INTO `audio` (`id`, `filename`, `title`, `description`, `place_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'dictumst_morbi_vestibulum.mp3', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'Morbi vel lectus in quam fringilla rhoncus.', 79, 3, 8, '2015-01-15 00:00:35', '2015-01-10 23:40:22', NULL),
(2, 'vivamus_vel.mp3', 'Pellentesque ultrices mattis odio.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti. Nullam porttitor lacus at turpis.', 57, 7, 6, '2015-01-03 16:40:03', '2015-01-13 12:28:38', NULL),
(3, 'mus_vivamus.avi', 'Sed vel enim sit amet nunc viverra dapibus.', 'Etiam justo.', 85, 5, 1, '2015-01-14 06:02:09', '2015-01-22 18:31:33', NULL),
(4, 'sit_amet_sapien.mp3', 'Duis bibendum.', 'Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl. Aenean lectus.', 17, 3, 1, '2015-01-29 12:40:45', '2015-01-18 00:06:43', NULL),
(5, 'in_porttitor.mp3', 'In hac habitasse platea dictumst.', 'Nulla nisl.', 36, 1, 2, '2015-01-05 16:44:00', '2015-01-10 12:49:20', NULL),
(6, 'tristique_in_tempus.mpeg', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'In eleifend quam a odio. In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt.', 67, 2, 3, '2015-01-10 00:43:36', '2015-01-13 03:34:51', NULL),
(7, 'risus_dapibus_augue.mpeg', 'Integer ac leo.', 'Suspendisse accumsan tortor quis turpis.', 55, 1, 7, '2015-01-16 21:06:02', '2015-01-12 07:53:52', NULL),
(8, 'justo_in.mp3', 'Pellentesque eget nunc.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio.', 71, 3, 5, '2015-01-20 18:23:20', '2015-01-21 01:08:07', NULL),
(9, 'dapibus_nulla.mp3', 'Nulla tellus.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst.', 42, 8, 4, '2015-01-22 18:06:54', '2015-01-14 18:38:35', NULL),
(10, 'mus_etiam_vel.mp3', 'Praesent lectus.', 'Vivamus in felis eu sapien cursus vestibulum. Proin eu mi. Nulla ac enim.', 44, 2, 6, '2015-01-30 14:14:20', '2015-01-09 07:15:20', NULL),
(11, 'imperdiet_sapien_urna.mp3', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', NULL, 86, 4, 5, '2015-01-01 07:19:08', '2015-01-23 16:52:50', NULL),
(12, 'fermentum_donec_ut.mp3', 'Aliquam quis turpis eget elit sodales scelerisque.', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem. Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy.', 91, 7, 2, '2015-01-05 23:57:33', '2015-01-23 20:20:57', NULL),
(13, 'fringilla_rhoncus_mauris.mov', 'Duis ac nibh.', NULL, NULL, 3, 8, '2015-01-11 23:29:48', '2015-01-03 03:11:20', NULL),
(14, 'imperdiet.avi', 'In hac habitasse platea dictumst.', 'Proin eu mi.', 48, 6, 6, '2015-01-27 03:18:01', '2015-01-28 08:38:16', NULL),
(15, 'a_suscipit.mov', 'Etiam faucibus cursus urna.', 'Fusce consequat.', 12, 6, 5, '2015-01-31 19:15:14', '2015-01-05 07:29:44', NULL),
(16, 'nulla_mollis_molestie.mov', 'Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 'Ut at dolor quis odio consequat varius.', 25, 1, 7, '2015-01-15 22:50:21', '2015-01-21 03:14:41', NULL),
(17, 'ut_erat_curabitur.mp3', 'Praesent id massa id nisl venenatis lacinia.', 'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 4, 3, 6, '2015-01-29 00:21:26', '2015-01-25 03:53:16', NULL),
(18, 'nisi_volutpat.mp3', 'In hac habitasse platea dictumst.', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti. In eleifend quam a odio.', 67, 1, 2, '2015-01-13 07:29:24', '2015-01-03 21:09:15', NULL),
(19, 'nulla_nunc_purus.mpeg', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', NULL, 64, 2, 2, '2015-01-18 06:46:57', '2015-01-05 10:41:26', NULL),
(20, 'sit_amet.avi', 'Aliquam quis turpis eget elit sodales scelerisque.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.', 72, 7, 2, '2015-01-04 16:33:31', '2015-01-18 03:50:03', NULL),
(21, 'morbi.mp3', 'Vestibulum sed magna at nunc commodo placerat.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus.', 82, 1, 6, '2015-01-31 07:28:27', '2015-01-23 07:54:25', NULL),
(22, 'non_mauris_morbi.mp3', 'Cras non velit nec nisi vulputate nonummy.', 'Nam tristique tortor eu pede.', 77, 4, 5, '2015-01-23 03:31:08', '2015-01-17 20:55:43', NULL),
(23, 'turpis_adipiscing_lorem.avi', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Proin risus. Praesent lectus. Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.', 52, 1, 3, '2015-01-15 08:09:53', '2015-01-22 15:38:56', NULL),
(24, 'magnis_dis_parturient.mov', 'Integer a nibh.', 'Nam dui. Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 75, 7, 4, '2015-01-04 02:07:06', '2015-01-25 03:18:37', NULL),
(25, 'iaculis_justo_in.avi', 'Suspendisse ornare consequat lectus.', 'Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 27, 1, 7, '2015-01-16 12:51:22', '2015-01-17 05:26:04', NULL),
(26, 'neque_libero.mpeg', 'Vivamus tortor.', NULL, 29, 8, 6, '2015-01-28 16:52:40', '2015-01-10 23:57:57', NULL),
(27, 'mauris_ullamcorper_purus.mpeg', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', NULL, 5, 1, '2015-01-06 14:17:08', '2015-01-25 16:30:24', NULL),
(28, 'nascetur.avi', 'Curabitur convallis.', 'Praesent id massa id nisl venenatis lacinia.', NULL, 8, 2, '2015-01-31 18:23:41', '2015-01-01 03:23:41', NULL),
(29, 'iaculis.mp3', 'Ut at dolor quis odio consequat varius.', 'Vivamus vestibulum sagittis sapien.', 74, 2, 4, '2015-01-21 22:24:05', '2015-01-26 01:17:07', NULL),
(30, 'accumsan.mp3', 'Sed ante.', 'Aenean sit amet justo. Morbi ut odio. Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo.', 2, 2, 5, '2015-01-25 23:53:30', '2015-01-21 13:02:45', NULL),
(31, 'vel_pede_morbi.mp3', 'Nullam sit amet turpis elementum ligula vehicula consequat.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus.', NULL, 6, 2, '2015-01-18 09:51:15', '2015-01-08 21:49:02', NULL),
(32, 'porta_volutpat_quam.mp3', 'Pellentesque viverra pede ac diam.', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 57, 2, 2, '2015-01-19 14:48:49', '2015-01-31 11:13:34', NULL),
(33, 'tristique_est.avi', 'Donec quis orci eget orci vehicula condimentum.', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', 71, 2, 3, '2015-01-01 08:26:28', '2015-01-15 09:38:30', NULL),
(34, 'posuere_cubilia.mp3', 'In hac habitasse platea dictumst.', 'Morbi non lectus.', 70, 2, 8, '2015-01-25 12:00:11', '2015-01-03 23:22:23', NULL),
(35, 'justo_sollicitudin.mpeg', 'Maecenas rhoncus aliquam lacus.', 'Phasellus in felis.', 77, 8, 8, '2015-01-01 17:36:35', '2015-01-09 09:01:13', NULL),
(36, 'viverra.mov', 'Aliquam non mauris.', 'Nullam sit amet turpis elementum ligula vehicula consequat.', 37, 5, 2, '2015-01-31 02:34:48', '2015-01-06 17:33:44', NULL),
(37, 'nonummy_integer_non.avi', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.', 'Praesent id massa id nisl venenatis lacinia.', NULL, 3, 3, '2015-01-16 11:25:06', '2015-01-27 09:49:48', NULL),
(38, 'vestibulum.avi', 'Mauris ullamcorper purus sit amet nulla.', 'Nunc nisl. Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', 18, 6, 5, '2015-01-24 06:23:22', '2015-01-10 23:42:34', NULL),
(39, 'ac_enim.avi', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Aliquam quis turpis eget elit sodales scelerisque.', 27, 4, 7, '2015-01-29 03:50:26', '2015-01-06 11:53:33', NULL),
(40, 'justo.mp3', 'Suspendisse potenti.', 'In eleifend quam a odio. In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt.', 88, 7, 4, '2015-01-01 12:29:14', '2015-01-03 06:18:15', NULL),
(41, 'vitae_consectetuer_eget.avi', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', NULL, 7, 3, '2015-01-23 00:03:44', '2015-01-13 20:41:02', NULL),
(42, 'nunc_proin.mp3', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.', 'Duis aliquam convallis nunc.', 36, 2, 8, '2015-01-23 06:22:41', '2015-01-04 02:09:42', NULL),
(43, 'magna.avi', 'Nulla suscipit ligula in lacus.', 'Morbi a ipsum. Integer a nibh. In quis justo.', 39, 4, 4, '2015-01-08 02:08:37', '2015-01-10 20:49:30', NULL),
(44, 'in.avi', 'Praesent blandit lacinia erat.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 43, 5, 8, '2015-01-15 01:50:11', '2015-01-02 02:27:28', NULL),
(45, 'sagittis_sapien.avi', 'Nullam molestie nibh in lectus.', 'Vestibulum sed magna at nunc commodo placerat.', NULL, 8, 5, '2015-01-01 02:55:21', '2015-01-28 07:23:00', NULL),
(46, 'morbi_odio.mp3', 'Curabitur in libero ut massa volutpat convallis.', 'Mauris ullamcorper purus sit amet nulla.', 13, 3, 7, '2015-01-24 13:57:54', '2015-01-14 05:51:17', NULL),
(47, 'dictumst_maecenas_ut.mp3', 'Mauris ullamcorper purus sit amet nulla.', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est. Phasellus sit amet erat.', 36, 1, 3, '2015-01-16 15:35:23', '2015-01-24 13:07:09', NULL),
(48, 'erat.mp3', 'Donec posuere metus vitae ipsum.', 'Vivamus in felis eu sapien cursus vestibulum. Proin eu mi. Nulla ac enim.', 81, 2, 1, '2015-01-16 20:30:59', '2015-01-17 17:38:34', NULL),
(49, 'sapien_urna.mov', 'Nulla facilisi.', 'Praesent blandit lacinia erat.', 46, 8, 7, '2015-01-26 23:52:07', '2015-01-09 14:48:09', NULL),
(50, 'morbi_odio_odio.mp3', 'Etiam justo.', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl.', 23, 2, 5, '2015-01-06 08:56:53', '2015-01-24 12:25:39', NULL),
(51, 'facilisi_cras_non.avi', 'In hac habitasse platea dictumst.', 'Nam nulla.', 29, 7, 8, '2015-01-07 13:35:52', '2015-01-30 23:48:36', NULL),
(52, 'parturient.mp3', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam.', 13, 5, 7, '2015-01-31 11:09:25', '2015-01-20 20:17:35', NULL),
(53, 'tristique_in_tempus.mp3', 'Praesent id massa id nisl venenatis lacinia.', 'Nulla tellus.', 21, 8, 6, '2015-01-20 16:44:52', '2015-01-28 14:33:27', NULL),
(54, 'cum.mp3', 'Praesent lectus.', 'Cras non velit nec nisi vulputate nonummy.', 10, 1, 2, '2015-01-14 20:43:10', '2015-01-17 03:20:39', NULL),
(55, 'dolor_sit_amet.avi', 'Praesent lectus.', NULL, 3, 8, 7, '2015-01-31 02:34:21', '2015-01-04 17:51:06', NULL),
(56, 'viverra_dapibus_nulla.mp3', 'Etiam vel augue.', 'Suspendisse potenti.', 23, 5, 5, '2015-01-07 23:44:28', '2015-01-10 22:12:55', NULL),
(57, 'primis_in.mp3', 'Duis aliquam convallis nunc.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 93, 6, 3, '2015-01-17 15:08:43', '2015-01-25 23:50:12', NULL),
(58, 'etiam_faucibus_cursus.mp3', 'In eleifend quam a odio.', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 32, 6, 5, '2015-01-10 05:22:54', '2015-01-30 10:57:59', NULL),
(59, 'suscipit.mp3', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo.', 'Mauris sit amet eros. Suspendisse accumsan tortor quis turpis. Sed ante.', 16, 4, 8, '2015-01-06 00:08:29', '2015-01-16 19:13:41', NULL),
(60, 'ligula_vehicula.mp3', 'In hac habitasse platea dictumst.', 'Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', NULL, 6, 8, '2015-01-04 00:13:39', '2015-01-17 13:15:13', NULL),
(61, 'habitasse_platea.mov', 'Sed ante.', 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 41, 7, 7, '2015-01-14 08:51:55', '2015-01-14 14:38:13', NULL),
(62, 'sapien_arcu_sed.avi', 'Proin risus.', 'Nullam porttitor lacus at turpis.', 44, 4, 1, '2015-01-09 04:36:32', '2015-01-11 22:58:53', NULL),
(63, 'velit.mp3', 'Pellentesque eget nunc.', 'Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', NULL, 4, 6, '2015-01-08 06:42:10', '2015-01-15 18:11:38', NULL),
(64, 'ac.mov', 'Etiam vel augue.', 'Phasellus sit amet erat.', 71, 7, 4, '2015-01-21 01:01:09', '2015-01-25 06:05:49', NULL),
(65, 'in_porttitor_pede.mp3', 'Donec dapibus.', NULL, 12, 1, 6, '2015-01-02 06:11:06', '2015-01-05 06:26:12', NULL),
(66, 'ultrices.mov', 'Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl.', 'Nunc rhoncus dui vel sem.', 64, 6, 6, '2015-01-14 03:09:45', '2015-01-12 15:02:40', NULL),
(67, 'tristique_est1.avi', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 91, 4, 8, '2015-01-13 15:00:52', '2015-01-24 02:52:56', NULL),
(68, 'curabitur.mp3', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 'Maecenas pulvinar lobortis est.', 97, 4, 1, '2015-01-12 01:02:46', '2015-01-10 17:03:18', NULL),
(69, 'sollicitudin_vitae_consectetuer.mp3', 'Vivamus vestibulum sagittis sapien.', 'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', NULL, 6, 2, '2015-01-13 21:19:16', '2015-01-19 00:09:13', NULL),
(70, 'molestie_lorem_quisque.mp3', 'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 65, 1, 5, '2015-01-18 02:31:30', '2015-01-13 16:27:45', NULL),
(71, 'pede_posuere_nonummy.mp3', 'Nullam varius.', 'Phasellus in felis. Donec semper sapien a libero. Nam dui.', 17, 5, 1, '2015-01-08 12:42:39', '2015-01-28 14:40:06', NULL),
(72, 'eget_tincidunt_eget.mp3', 'Morbi vel lectus in quam fringilla rhoncus.', 'Proin at turpis a pede posuere nonummy. Integer non velit.', 64, 6, 2, '2015-01-23 01:55:05', '2015-01-09 21:46:35', NULL),
(73, 'hac_habitasse_platea.avi', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 'Integer a nibh.', 76, 5, 8, '2015-01-11 00:20:35', '2015-01-06 20:29:26', NULL),
(74, 'mauris.avi', 'Morbi ut odio.', NULL, 47, 1, 4, '2015-01-02 17:44:52', '2014-12-31 23:14:24', NULL),
(75, 'dis_parturient_montes.avi', 'Aenean sit amet justo.', 'Pellentesque at nulla.', NULL, 4, 7, '2015-01-20 21:50:04', '2015-01-09 04:36:44', NULL),
(76, 'lacus_at_turpis.avi', 'Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 'Quisque ut erat.', 93, 8, 5, '2015-01-12 13:53:51', '2015-01-24 03:19:04', NULL),
(77, 'at.mp3', 'Sed ante.', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 85, 5, 7, '2015-01-27 13:23:48', '2015-01-27 07:35:49', NULL),
(78, 'ornare.avi', 'Nunc rhoncus dui vel sem.', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor.', 64, 2, 2, '2015-01-09 12:35:47', '2015-01-20 14:01:08', NULL),
(79, 'vulputate.mp3', 'Nulla tellus.', 'Suspendisse potenti.', 33, 2, 8, '2015-01-01 19:57:42', '2015-01-29 21:34:31', NULL),
(80, 'quisque_ut_erat.avi', 'Vivamus in felis eu sapien cursus vestibulum.', 'Fusce consequat. Nulla nisl. Nunc nisl.', 52, 2, 5, '2015-01-26 06:09:46', '2015-01-02 01:26:49', NULL),
(81, 'consequat.avi', 'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla.', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 31, 2, 1, '2015-01-22 21:48:22', '2015-01-15 11:06:57', NULL),
(82, 'nisi_venenatis_tristique.avi', 'In blandit ultrices enim.', 'Morbi ut odio.', 53, 7, 8, '2015-01-21 20:19:14', '2015-01-07 16:11:54', NULL),
(83, 'nisl.mov', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Etiam pretium iaculis justo. In hac habitasse platea dictumst. Etiam faucibus cursus urna.', 44, 8, 1, '2015-01-02 16:31:45', '2015-01-09 15:09:44', NULL),
(84, 'non_mauris.avi', 'Nam nulla.', 'Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 97, 6, 2, '2015-01-15 23:44:50', '2015-01-28 02:22:17', NULL),
(85, 'duis.avi', 'Quisque id justo sit amet sapien dignissim vestibulum.', 'Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 24, 2, 7, '2015-01-06 18:17:02', '2015-01-25 10:17:10', NULL),
(86, 'varius_ut.avi', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', NULL, 37, 4, 2, '2015-01-20 20:23:05', '2015-01-13 18:21:04', NULL),
(87, 'sapien_ut.avi', 'Integer ac leo.', NULL, 10, 2, 2, '2015-01-06 02:23:36', '2015-01-16 17:31:37', NULL),
(88, 'blandit.mpeg', 'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'Fusce posuere felis sed lacus.', 80, 4, 8, '2015-01-14 10:27:01', '2015-01-16 04:54:56', NULL),
(89, 'rutrum.mpeg', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Sed ante. Vivamus tortor.', 34, 6, 5, '2015-01-21 06:00:02', '2015-01-15 20:33:12', NULL),
(90, 'ridiculus_mus_vivamus.mpeg', 'Maecenas pulvinar lobortis est.', 'Phasellus sit amet erat.', NULL, 2, 6, '2015-01-04 18:34:18', '2015-01-30 20:37:42', NULL),
(91, 'porttitor_pede.mp3', 'Maecenas tincidunt lacus at velit.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', 7, 1, 4, '2015-01-09 00:44:07', '2015-01-25 23:34:05', NULL),
(92, 'leo_odio_porttitor.mp3', 'Vivamus vel nulla eget eros elementum pellentesque.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', NULL, 2, 6, '2015-01-18 19:18:23', '2015-01-19 12:54:43', NULL),
(93, 'id.avi', 'Suspendisse accumsan tortor quis turpis.', 'Etiam justo. Etiam pretium iaculis justo. In hac habitasse platea dictumst.', 50, 3, 5, '2015-01-27 21:36:14', '2015-01-08 12:25:50', NULL),
(94, 'pede.mov', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 'Proin interdum mauris non ligula pellentesque ultrices.', 78, 8, 6, '2015-01-22 10:31:50', '2015-01-08 04:10:14', NULL),
(95, 'nullam_sit.mp3', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 'Phasellus in felis. Donec semper sapien a libero.', 37, 4, 4, '2015-01-29 20:44:04', '2015-01-03 22:24:43', NULL),
(96, 'vestibulum_ante_ipsum.mp3', 'Phasellus sit amet erat.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 1, 8, 7, '2015-01-10 05:57:36', '2015-01-26 03:02:15', NULL),
(97, 'sit_amet.mov', 'In hac habitasse platea dictumst.', 'Quisque ut erat.', 89, 7, 3, '2015-01-09 05:46:25', '2015-01-24 11:25:57', NULL),
(98, 'convallis.avi', 'Donec dapibus.', 'Vivamus vel nulla eget eros elementum pellentesque.', 53, 6, 3, '2015-01-30 07:50:26', '2015-01-28 07:57:37', NULL),
(99, 'magna_ac.avi', 'Vivamus vel nulla eget eros elementum pellentesque.', 'Morbi vel lectus in quam fringilla rhoncus. Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', NULL, 8, 5, '2015-01-16 03:31:09', '2015-01-17 07:54:25', NULL),
(100, 'proin_interdum.mp3', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 'Aliquam non mauris. Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.', 54, 8, 7, '2015-01-19 05:04:21', '2015-01-29 16:01:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Administrator', '2015-02-01 10:49:51', '2015-02-01 10:49:51', NULL),
(2, 'Moderator', '2015-02-01 10:49:51', '2015-02-01 10:49:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
`id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `filename`, `title`, `description`, `place_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'in_faucibus.tiff', 'Duis bibendum.', NULL, 65, 5, 1, '2015-01-16 04:21:11', '2015-01-10 03:20:16', NULL),
(2, 'at_diam.tiff', 'Donec ut dolor.', 'Vestibulum sed magna at nunc commodo placerat.', 23, 8, 1, '2015-01-17 04:52:19', '2015-01-07 05:08:36', NULL),
(3, 'montes.jpeg', 'In blandit ultrices enim.', 'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo.', 5, 7, 6, '2015-01-29 19:16:14', '2015-01-29 11:01:34', NULL),
(4, 'parturient.jpeg', 'Donec semper sapien a libero.', 'Suspendisse potenti.', 18, 5, 7, '2015-01-21 15:54:51', '2015-01-21 06:49:44', NULL),
(5, 'risus.tiff', 'In hac habitasse platea dictumst.', 'Quisque id justo sit amet sapien dignissim vestibulum.', NULL, 6, 1, '2015-01-25 06:47:28', '2015-01-06 03:41:07', NULL),
(6, 'tempus.tiff', 'Mauris ullamcorper purus sit amet nulla.', 'Nulla suscipit ligula in lacus. Curabitur at ipsum ac tellus semper interdum.', 13, 8, 8, '2015-01-12 15:57:00', '2015-01-29 08:44:44', NULL),
(7, 'montes.png', 'Aliquam quis turpis eget elit sodales scelerisque.', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 3, 8, 8, '2015-01-30 20:50:23', '2015-01-02 12:36:46', NULL),
(8, 'magna_vestibulum.png', 'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.', NULL, 4, 5, '2015-01-13 14:08:36', '2015-01-30 17:02:20', NULL),
(9, 'interdum_venenatis_turpis.tiff', 'Nulla tempus.', 'Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 14, 8, 5, '2015-01-27 08:41:00', '2015-01-29 19:30:12', NULL),
(10, 'lacinia_eget.jpeg', 'Maecenas pulvinar lobortis est.', 'Integer ac leo.', 31, 2, 2, '2015-01-26 10:29:26', '2015-01-06 16:54:08', NULL),
(11, 'hendrerit.tiff', 'Mauris ullamcorper purus sit amet nulla.', 'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo.', 23, 2, 2, '2015-01-10 07:17:01', '2015-01-24 15:07:50', NULL),
(12, 'dapibus_dolor_vel.png', 'Suspendisse potenti.', 'Sed ante.', 57, 4, 5, '2015-01-04 20:47:34', '2015-01-23 11:09:23', NULL),
(13, 'at.tiff', 'Mauris ullamcorper purus sit amet nulla.', 'In eleifend quam a odio. In hac habitasse platea dictumst.', NULL, 2, 8, '2015-01-29 22:45:01', '2015-01-31 09:45:00', NULL),
(14, 'in.tiff', 'Vivamus tortor.', 'Nam tristique tortor eu pede.', NULL, 5, 5, '2015-01-31 10:05:15', '2015-01-25 00:44:23', NULL),
(15, 'rutrum.jpeg', 'Duis mattis egestas metus.', 'Aliquam sit amet diam in magna bibendum imperdiet.', NULL, 6, 7, '2015-01-27 05:03:31', '2015-01-26 09:52:19', NULL),
(16, 'feugiat_non.jpeg', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Fusce posuere felis sed lacus.', NULL, 3, 2, '2015-01-02 14:57:34', '2015-01-30 12:24:31', NULL),
(17, 'dictumst_maecenas_ut.tiff', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 76, 3, 8, '2015-01-25 11:32:26', '2015-01-22 17:27:55', NULL),
(18, 'natoque_penatibus_et.tiff', 'Nullam porttitor lacus at turpis.', 'Nunc purus. Phasellus in felis.', 41, 7, 1, '2015-01-03 20:56:37', '2015-01-21 03:02:30', NULL),
(19, 'mauris_vulputate_elementum.jpeg', 'Etiam vel augue.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 92, 6, 7, '2015-01-22 03:11:00', '2015-01-26 20:07:27', NULL),
(20, 'congue.gif', 'Cras pellentesque volutpat dui.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 31, 6, 6, '2015-01-07 01:25:56', '2015-01-09 13:45:21', NULL),
(21, 'vestibulum_velit_id.png', 'Morbi a ipsum.', 'Nam dui. Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 14, 5, 1, '2015-01-06 23:27:40', '2015-01-22 03:23:47', NULL),
(22, 'neque_libero_convallis.jpeg', 'Sed vel enim sit amet nunc viverra dapibus.', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.', 18, 8, 2, '2015-01-04 07:49:18', '2015-01-08 17:15:06', NULL),
(23, 'rhoncus_aliquet.png', 'Aenean auctor gravida sem.', 'Integer ac neque. Duis bibendum.', 39, 3, 5, '2015-01-13 22:32:33', '2015-01-18 13:52:53', NULL),
(24, 'cubilia.jpeg', 'Suspendisse accumsan tortor quis turpis.', NULL, NULL, 6, 2, '2015-01-01 05:20:06', '2015-01-18 19:23:20', NULL),
(25, 'quis.png', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 'Ut at dolor quis odio consequat varius. Integer ac leo. Pellentesque ultrices mattis odio.', 38, 4, 5, '2015-01-23 00:52:21', '2015-01-20 08:07:45', NULL),
(26, 'donec_odio.jpeg', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', NULL, 88, 6, 5, '2015-01-26 14:05:55', '2015-01-15 03:34:14', NULL),
(27, 'eleifend_pede_libero.tiff', 'Integer ac leo.', NULL, 19, 2, 4, '2015-01-02 08:14:14', '2015-01-27 07:22:44', NULL),
(28, 'fusce_congue_diam.jpeg', 'Praesent blandit.', 'Pellentesque ultrices mattis odio. Donec vitae nisi. Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla.', 40, 3, 5, '2015-01-21 04:35:37', '2015-01-15 15:37:23', NULL),
(29, 'etiam.tiff', 'Aenean auctor gravida sem.', 'Aenean sit amet justo. Morbi ut odio.', 45, 1, 2, '2015-01-05 05:26:00', '2015-01-25 22:38:22', NULL),
(30, 'sem_fusce.jpeg', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi.', 'Suspendisse potenti. Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 97, 2, 8, '2015-01-10 00:55:25', '2015-01-20 22:23:19', NULL),
(31, 'nulla_dapibus_dolor.gif', 'Sed vel enim sit amet nunc viverra dapibus.', NULL, 92, 1, 7, '2015-01-18 11:12:51', '2015-01-01 00:15:46', NULL),
(32, 'luctus_et_ultrices.jpeg', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', 'Nullam varius. Nulla facilisi.', 25, 7, 5, '2015-01-13 07:21:35', '2015-01-16 04:26:37', NULL),
(33, 'nulla_tempus.gif', 'Integer a nibh.', 'Aliquam erat volutpat. In congue. Etiam justo.', NULL, 6, 4, '2015-01-02 20:05:55', '2015-01-17 13:14:12', NULL),
(34, 'magna_vulputate_luctus.jpeg', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'Vivamus tortor.', 56, 1, 1, '2015-01-04 23:35:31', '2015-01-03 03:47:39', NULL),
(35, 'tristique.png', 'Vestibulum sed magna at nunc commodo placerat.', 'Vivamus in felis eu sapien cursus vestibulum.', 29, 2, 2, '2015-01-26 19:42:09', '2015-01-17 02:26:21', NULL),
(36, 'mi_nulla.jpeg', 'Donec semper sapien a libero.', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero. Nullam sit amet turpis elementum ligula vehicula consequat.', 85, 5, 7, '2015-01-31 12:31:03', '2015-01-13 09:22:04', NULL),
(37, 'sapien.tiff', 'Phasellus id sapien in sapien iaculis congue.', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 78, 1, 7, '2015-01-27 09:54:24', '2015-01-22 11:48:10', NULL),
(38, 'primis_in_faucibus.jpeg', 'Morbi non lectus.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis.', NULL, 2, 5, '2015-01-07 12:58:44', '2015-01-21 20:54:23', NULL),
(39, 'nascetur_ridiculus_mus.jpeg', 'Nullam porttitor lacus at turpis.', 'Cras in purus eu magna vulputate luctus.', 1, 1, 4, '2015-01-02 15:28:01', '2015-01-15 12:59:36', NULL),
(40, 'ultrices_phasellus.jpeg', 'Nullam sit amet turpis elementum ligula vehicula consequat.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', 54, 3, 8, '2015-01-03 17:46:19', '2015-01-26 23:23:11', NULL),
(41, 'curae_nulla.tiff', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', NULL, 12, 5, 5, '2015-01-08 15:11:25', '2015-01-24 03:23:47', NULL),
(42, 'elementum_eu_interdum.png', 'Nunc purus.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 25, 7, 6, '2015-01-16 10:02:52', '2015-01-25 16:09:07', NULL),
(43, 'nulla_tempus_vivamus.tiff', 'Donec vitae nisi.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 68, 7, 5, '2015-01-06 03:19:55', '2015-01-10 09:15:09', NULL),
(44, 'amet_turpis.tiff', 'Maecenas rhoncus aliquam lacus.', NULL, NULL, 2, 7, '2015-01-05 02:52:35', '2015-01-12 22:37:21', NULL),
(45, 'magnis_dis.gif', 'In blandit ultrices enim.', 'In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin interdum mauris non ligula pellentesque ultrices.', 86, 8, 3, '2015-01-30 23:06:41', '2015-01-05 00:32:53', NULL),
(46, 'rutrum_ac.tiff', 'Cras pellentesque volutpat dui.', 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem. Integer tincidunt ante vel ipsum.', 20, 4, 7, '2015-01-11 17:51:58', '2015-01-16 08:05:01', NULL),
(47, 'congue_risus.png', 'Etiam vel augue.', 'Morbi non quam nec dui luctus rutrum. Nulla tellus. In sagittis dui vel nisl.', 22, 8, 8, '2015-01-17 17:16:22', '2015-01-03 21:32:01', NULL),
(48, 'aenean_fermentum_donec.gif', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'Aliquam non mauris. Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.', 81, 8, 8, '2015-01-05 17:29:44', '2015-01-13 13:04:27', NULL),
(49, 'id_justo.tiff', 'Aenean lectus.', NULL, 22, 4, 3, '2015-01-06 14:49:28', '2015-01-31 10:06:23', NULL),
(50, 'dapibus.tiff', 'In blandit ultrices enim.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus.', 77, 5, 4, '2015-01-07 02:14:30', '2015-01-31 02:10:37', NULL),
(51, 'volutpat_erat.gif', 'Aliquam sit amet diam in magna bibendum imperdiet.', NULL, 74, 2, 8, '2015-01-18 00:08:04', '2015-01-07 06:14:27', NULL),
(52, 'tortor_id.jpeg', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 'Duis consequat dui nec nisi volutpat eleifend.', 98, 1, 6, '2015-01-06 18:29:10', '2015-01-09 16:05:31', NULL),
(53, 'dis.jpeg', 'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Suspendisse accumsan tortor quis turpis.', 18, 6, 4, '2015-01-25 10:31:49', '2015-01-08 08:49:48', NULL),
(54, 'aenean.jpeg', 'Duis aliquam convallis nunc.', 'Nunc nisl. Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', 30, 7, 1, '2015-01-31 11:13:23', '2015-01-30 08:31:23', NULL),
(55, 'volutpat.gif', 'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla.', NULL, 2, 2, 8, '2015-01-20 16:57:53', '2015-01-05 15:33:10', NULL),
(56, 'imperdiet_et_commodo.png', 'Aliquam non mauris.', 'Aenean sit amet justo. Morbi ut odio.', NULL, 5, 4, '2015-01-20 22:31:22', '2015-01-10 15:14:07', NULL),
(57, 'volutpat_in_congue.tiff', 'Curabitur in libero ut massa volutpat convallis.', 'Integer ac neque.', 62, 6, 2, '2015-01-17 16:46:49', '2015-01-20 11:39:29', NULL),
(58, 'sit_amet_eleifend.gif', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Duis mattis egestas metus. Aenean fermentum.', 19, 2, 5, '2015-01-20 05:19:58', '2015-01-09 23:56:19', NULL),
(59, 'augue_luctus_tincidunt.jpeg', 'Vivamus vestibulum sagittis sapien.', 'In eleifend quam a odio. In hac habitasse platea dictumst.', 56, 3, 3, '2015-01-13 20:14:58', '2015-01-29 00:38:49', NULL),
(60, 'tellus_semper.tiff', 'Suspendisse potenti.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum.', 12, 7, 6, '2015-01-12 00:24:22', '2015-01-30 09:26:44', NULL),
(61, 'elementum.png', 'In hac habitasse platea dictumst.', 'Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 16, 3, 8, '2015-01-06 13:50:54', '2015-01-28 20:58:56', NULL),
(62, 'laoreet.jpeg', 'Donec ut dolor.', 'Nulla nisl. Nunc nisl. Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', 3, 4, 4, '2015-01-13 00:50:50', '2015-01-03 22:22:31', NULL),
(63, 'morbi_a_ipsum.png', 'Mauris lacinia sapien quis libero.', 'Quisque ut erat. Curabitur gravida nisi at nibh.', 22, 8, 1, '2015-01-13 04:42:54', '2015-01-11 05:39:34', NULL),
(64, 'turpis_eget_elit.png', 'Cras non velit nec nisi vulputate nonummy.', NULL, NULL, 7, 7, '2015-01-16 16:59:55', '2015-01-31 06:29:23', NULL),
(65, 'vulputate_vitae_nisl.jpeg', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.', 92, 5, 4, '2015-01-24 17:45:28', '2015-01-17 05:38:20', NULL),
(66, 'cubilia_curae.gif', 'Proin risus.', 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem. Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat.', 64, 4, 4, '2015-01-20 16:05:53', '2015-01-09 15:51:36', NULL),
(67, 'nisl_nunc.gif', 'Morbi vel lectus in quam fringilla rhoncus.', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 80, 8, 3, '2015-01-12 05:37:00', '2015-01-12 02:28:42', NULL),
(68, 'placerat.png', 'Vivamus in felis eu sapien cursus vestibulum.', 'Integer tincidunt ante vel ipsum.', 41, 1, 4, '2015-01-19 18:37:07', '2015-01-23 07:18:52', NULL),
(69, 'volutpat_sapien.png', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum.', 59, 3, 6, '2015-01-03 18:25:09', '2015-01-06 07:11:52', NULL),
(70, 'viverra.jpeg', 'Nam nulla.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', 53, 2, 3, '2015-01-27 18:49:43', '2015-01-14 23:26:49', NULL),
(71, 'aliquet.tiff', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.', 'Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 78, 1, 7, '2015-01-18 15:49:06', '2015-01-18 13:39:01', NULL),
(72, 'lorem_vitae_mattis.jpeg', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 'Vivamus tortor. Duis mattis egestas metus. Aenean fermentum.', 11, 7, 3, '2015-01-06 16:00:25', '2015-01-20 06:44:08', NULL),
(73, 'nulla_integer.jpeg', 'Etiam justo.', 'Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus. Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', 35, 6, 4, '2015-01-26 10:02:22', '2015-01-27 17:58:14', NULL),
(74, 'vitae_nisi.png', 'Mauris sit amet eros.', 'Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 84, 6, 5, '2015-01-22 10:04:02', '2015-01-26 06:12:15', NULL),
(75, 'tortor_id_nulla.tiff', 'Morbi quis tortor id nulla ultrices aliquet.', 'Morbi quis tortor id nulla ultrices aliquet.', 80, 4, 5, '2015-01-01 05:57:28', '2015-01-28 03:15:26', NULL),
(76, 'cum_sociis.tiff', 'Mauris lacinia sapien quis libero.', 'In sagittis dui vel nisl. Duis ac nibh.', 11, 2, 6, '2015-01-11 15:45:38', '2015-01-06 23:00:14', NULL),
(77, 'natoque_penatibus.tiff', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Suspendisse potenti.', 74, 2, 3, '2015-01-08 05:03:38', '2015-01-03 20:57:53', NULL),
(78, 'in_imperdiet_et.png', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus.', 87, 1, 3, '2015-01-10 07:59:22', '2015-01-08 02:51:19', NULL),
(79, 'mauris_enim.jpeg', 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 77, 8, 4, '2015-01-17 07:08:07', '2015-01-03 07:47:34', NULL),
(80, 'malesuada_in.tiff', 'Suspendisse potenti.', 'Vestibulum rutrum rutrum neque. Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia.', 40, 8, 4, '2015-01-01 21:18:22', '2015-01-30 19:03:58', NULL),
(81, 'platea.jpeg', 'Maecenas pulvinar lobortis est.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', NULL, 7, 4, '2015-01-06 06:12:14', '2015-01-12 14:17:26', NULL),
(82, 'est_et_tempus.jpeg', 'Donec dapibus.', 'In hac habitasse platea dictumst.', NULL, 4, 1, '2015-01-15 22:06:57', '2015-01-01 00:47:08', NULL),
(83, 'massa.gif', 'Phasellus in felis.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus.', 57, 2, 7, '2015-01-18 19:46:57', '2015-01-09 06:04:22', NULL),
(84, 'duis_at_velit.gif', 'In sagittis dui vel nisl.', 'In est risus, auctor sed, tristique in, tempus sit amet, sem.', 84, 6, 3, '2015-01-27 13:06:43', '2015-01-01 07:20:17', NULL),
(85, 'eget.tiff', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 'Donec vitae nisi. Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus.', NULL, 3, 5, '2015-01-29 03:08:44', '2015-01-11 00:01:00', NULL),
(86, 'est_donec_odio.png', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 14, 6, 4, '2015-01-26 00:47:41', '2015-01-26 12:28:39', NULL),
(87, 'interdum_mauris_ullamcorper.png', 'Pellentesque eget nunc.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem.', 12, 1, 4, '2015-01-21 09:23:55', '2015-01-09 16:13:42', NULL),
(88, 'congue_vivamus.gif', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', NULL, NULL, 7, 4, '2015-01-16 13:09:42', '2015-01-24 15:56:13', NULL),
(89, 'consequat.gif', 'Vivamus vel nulla eget eros elementum pellentesque.', 'Morbi porttitor lorem id ligula.', 68, 8, 3, '2015-01-05 11:55:46', '2015-01-24 12:52:39', NULL),
(90, 'diam.tiff', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 'Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl.', NULL, 7, 4, '2015-01-21 18:19:40', '2015-01-22 00:04:20', NULL),
(91, 'congue_eget_semper.tiff', 'Mauris lacinia sapien quis libero.', 'Morbi vel lectus in quam fringilla rhoncus. Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', NULL, 6, 3, '2015-01-19 14:39:16', '2015-01-14 21:56:36', NULL),
(92, 'praesent_lectus_vestibulum.tiff', 'Fusce posuere felis sed lacus.', NULL, 70, 3, 2, '2015-01-24 11:15:07', '2015-01-23 10:35:28', NULL),
(93, 'elementum.gif', 'Proin risus.', 'Praesent lectus. Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio.', 25, 6, 6, '2015-01-27 09:06:41', '2015-01-24 03:59:31', NULL),
(94, 'pede_malesuada.gif', 'Mauris lacinia sapien quis libero.', 'Integer a nibh. In quis justo. Maecenas rhoncus aliquam lacus.', 23, 1, 8, '2015-01-01 10:45:43', '2015-01-07 08:03:51', NULL),
(95, 'suspendisse.tiff', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum.', NULL, 4, 8, '2015-01-20 15:07:00', '2015-01-08 19:39:49', NULL),
(96, 'dui_maecenas_tristique.jpeg', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', 'Aliquam quis turpis eget elit sodales scelerisque.', 55, 6, 3, '2015-01-28 08:25:04', '2015-01-29 07:42:15', NULL),
(97, 'dis.png', 'In blandit ultrices enim.', 'In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem. Integer tincidunt ante vel ipsum.', 74, 5, 7, '2015-01-31 17:45:13', '2015-01-21 08:12:27', NULL),
(98, 'viverra1.jpeg', 'Nunc nisl.', 'Nulla justo. Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros.', NULL, 6, 4, '2015-01-10 21:08:34', '2015-01-21 21:47:37', NULL),
(99, 'semper.png', 'Pellentesque at nulla.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum.', 46, 1, 8, '2015-01-19 16:15:10', '2015-01-05 20:04:16', NULL),
(100, 'in_quis_justo.tiff', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 36, 5, 1, '2015-01-26 19:33:30', '2015-01-30 01:13:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_02_01_104615_create_groups_table', 1),
('2015_02_01_104633_create_users_table', 1),
('2015_02_01_104649_create_place_types_table', 1),
('2015_02_01_104659_create_places_table', 1),
('2015_02_01_104711_create_articles_table', 1),
('2015_02_01_104726_create_images_table', 1),
('2015_02_01_104738_create_audio_table', 1),
('2015_02_01_104749_create_video_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
`id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lat` decimal(9,6) NOT NULL,
  `lng` decimal(9,6) NOT NULL,
  `place_type_id` int(10) unsigned NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `name`, `description`, `address`, `phone`, `email`, `url`, `lat`, `lng`, `place_type_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Snaptags', 'Nulla suscipit ligula in lacus.', '06 Holmberg Drive', '3-(415)380-8519', 'jcollins0@i2i.jp', 'https://so-net.ne.jp', '34.462500', '108.734440', 82, 6, 5, '2015-01-31 13:50:22', '2015-01-27 14:05:04', NULL),
(2, 'Cogibox', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', '3 Towne Pass', '2-(753)135-1605', 'rwelch1@cmu.edu', 'https://fotki.com', '30.192220', '121.225200', 44, 3, 6, '2015-01-10 06:08:01', '2015-01-25 15:43:39', NULL),
(3, 'Topicblab', NULL, NULL, '6-(279)222-0540', 'rbishop2@auda.org.au', 'https://washingtonpost.com', '47.750000', '7.333300', 89, 7, 6, '2015-01-14 18:50:07', '2015-01-19 03:14:32', NULL),
(4, 'Fivebridge', 'Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', '771 Thompson Place', '5-(231)993-9802', NULL, 'https://sitemeter.com', '-23.193610', '-49.383890', 24, 5, 8, '2015-01-28 21:59:34', '2015-01-21 21:13:09', NULL),
(5, 'Voonyx', 'Pellentesque at nulla.', '74523 Hoard Drive', '3-(123)075-1206', 'hbowman4@sciencedaily.com', 'https://opera.com', '47.441090', '-70.498580', 39, 5, 7, '2015-01-27 01:21:45', '2015-01-12 15:03:29', NULL),
(6, 'Edgeclub', 'Integer a nibh.', '778 Eliot Drive', NULL, 'charper5@berkeley.edu', 'http://domainmarket.com', '-3.993130', '-79.204220', 23, 7, 3, '2015-01-22 20:34:56', '2015-01-18 14:40:06', NULL),
(7, 'Aimbo', 'Proin interdum mauris non ligula pellentesque ultrices.', NULL, '5-(429)818-3507', 'bmedina6@ox.ac.uk', 'http://eepurl.com', '39.150800', '-9.161600', 44, 3, 6, '2015-01-29 13:13:17', '2015-01-12 19:56:19', NULL),
(8, 'Wordify', 'Mauris lacinia sapien quis libero. Nullam sit amet turpis elementum ligula vehicula consequat.', '34294 Clyde Gallagher Street', '8-(099)221-5944', 'psims7@sogou.com', 'https://live.com', '44.850000', '0.483300', 39, 5, 1, '2015-01-05 14:50:56', '2015-01-29 11:24:03', NULL),
(9, 'Mymm', 'Pellentesque ultrices mattis odio. Donec vitae nisi. Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla.', '068 Amoth Circle', '8-(735)837-9741', NULL, 'https://apple.com', '29.035680', '92.979330', 56, 3, 5, '2015-01-02 01:11:57', '2015-01-30 17:26:28', NULL),
(10, 'Digitube', 'Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius.', '7 Acker Way', '0-(469)116-8315', 'jcarroll9@theguardian.com', NULL, '12.286700', '10.352700', 33, 6, 8, '2015-01-25 06:50:19', '2015-01-09 13:45:09', NULL),
(11, 'Vinder', 'Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl. Aenean lectus.', '557 John Wall Court', NULL, NULL, 'http://weibo.com', '40.761100', '-73.968000', 25, 8, 5, '2015-01-17 17:32:16', '2015-01-22 22:46:18', NULL),
(12, 'Leenti', 'In hac habitasse platea dictumst.', '7 Lien Parkway', '0-(191)275-7869', 'lgordonb@freewebs.com', NULL, '40.100000', '-7.466700', 88, 1, 1, '2015-01-29 15:52:07', '2015-01-01 19:28:50', NULL),
(13, 'Aivee', 'Integer a nibh. In quis justo. Maecenas rhoncus aliquam lacus.', '69439 Old Shore Avenue', '5-(680)744-2142', 'jcarpenterc@illinois.edu', 'http://wired.com', '36.009580', '106.276140', 89, 1, 6, '2015-01-04 14:45:55', '2015-01-11 08:45:49', NULL),
(14, 'Oyoyo', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti.', '1 Moose Trail', '0-(079)110-2686', NULL, 'https://nytimes.com', '41.733330', '23.150000', 36, 2, 6, '2015-01-06 03:39:57', '2015-01-13 14:02:49', NULL),
(15, 'Meemm', 'Pellentesque eget nunc.', '175 Pepper Wood Alley', NULL, 'jandrewse@seesaa.net', 'https://blinklist.com', '42.930560', '16.896390', 70, 5, 1, '2015-01-20 16:15:26', '2015-01-28 09:00:15', NULL),
(16, 'InnoZ', 'Vestibulum rutrum rutrum neque.', '32336 Lillian Place', '3-(037)559-2236', 'lperezf@nydailynews.com', 'https://facebook.com', '27.107660', '103.256580', 59, 5, 2, '2015-01-04 17:57:30', '2015-01-12 21:12:14', NULL),
(17, 'Minyx', 'Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat.', '7613 Sundown Junction', '1-(758)849-4282', 'jelliottg@wikimedia.org', 'https://si.edu', '-21.137780', '-47.990280', 57, 3, 3, '2015-01-22 16:23:12', '2015-01-03 00:42:34', NULL),
(18, 'Trilith', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', '3103 Myrtle Pass', '9-(215)464-5739', 'sdayh@loc.gov', 'http://thetimes.co.uk', '14.722600', '102.025120', 24, 5, 8, '2015-01-01 04:51:48', '2015-01-05 06:06:22', NULL),
(19, 'Plajo', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus.', NULL, '8-(800)318-7425', 'lrayi@army.mil', 'https://berkeley.edu', '-43.300000', '-65.700000', 86, 6, 8, '2015-01-22 16:00:14', '2015-01-26 10:22:58', NULL),
(20, 'Eire', 'In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', '3 Dawn Parkway', NULL, 'nellisj@jugem.jp', 'http://studiopress.com', '-22.923060', '-53.137220', 47, 1, 8, '2015-01-12 17:08:05', '2015-01-10 03:02:49', NULL),
(21, 'Vinte', 'Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', '5 Gina Alley', '9-(765)485-3570', 'nfernandezk@imdb.com', 'http://moonfruit.com', '-23.110000', '-50.367500', 41, 1, 3, '2015-01-27 21:15:08', '2015-01-19 20:16:32', NULL),
(22, 'Geba', 'In quis justo.', '800 Northfield Point', '8-(373)418-5709', NULL, 'https://nasa.gov', '33.733330', '135.366670', 46, 5, 6, '2015-01-12 08:50:46', '2015-01-08 02:43:34', NULL),
(23, 'Jabberbean', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus.', NULL, '0-(809)419-5738', 'rvasquezm@imageshack.us', 'https://aol.com', '23.082010', '113.218240', 48, 4, 7, '2015-01-05 01:09:18', '2015-01-31 07:23:19', NULL),
(24, 'Jayo', 'Nulla facilisi.', '119 Fallview Avenue', '1-(914)731-3880', 'hpetersonn@storify.com', 'http://shinystat.com', '43.105280', '46.190450', 69, 1, 3, '2015-01-04 12:35:41', '2015-01-24 15:19:12', NULL),
(25, 'Rooxo', 'Nullam varius.', '2076 Meadow Ridge Parkway', '8-(126)730-6360', 'kwilsono@tmall.com', 'https://tripod.com', '38.105830', '127.989440', 35, 5, 3, '2015-01-17 07:54:25', '2015-01-04 18:00:58', NULL),
(26, 'Livetube', 'Vivamus vestibulum sagittis sapien.', '0935 Goodland Way', '5-(303)395-2374', 'tpalmerp@scribd.com', 'https://slate.com', '4.873930', '-75.171510', 36, 5, 6, '2015-01-15 17:35:41', '2015-01-25 01:59:20', NULL),
(27, 'Dynabox', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', '9 Doe Crossing Parkway', '8-(960)840-1174', 'rpowellq@free.fr', 'http://tripadvisor.com', '-8.084300', '113.875800', 12, 7, 8, '2015-01-01 08:44:37', '2015-01-16 05:44:58', NULL),
(28, 'Livefish', 'Sed accumsan felis.', '2 Larry Street', '9-(853)301-9454', 'awardr@whitehouse.gov', 'https://xinhuanet.com', '41.339400', '-8.616700', 39, 5, 3, '2015-01-24 16:44:13', '2015-01-11 05:17:53', NULL),
(29, 'Meedoo', 'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', '5 Glendale Point', '6-(649)151-3143', NULL, 'https://flickr.com', '22.255250', '106.473590', 80, 6, 2, '2015-01-14 09:33:20', '2015-01-04 22:12:53', NULL),
(30, 'Livepath', 'Nullam varius. Nulla facilisi.', '4559 Kedzie Place', '9-(354)648-1964', 'alanet@smh.com.au', 'https://nature.com', '34.072500', '105.736940', 25, 1, 5, '2015-01-29 23:57:42', '2015-01-27 06:57:58', NULL),
(31, 'Wordtune', 'Suspendisse potenti.', '83792 Carberry Hill', '4-(871)619-3916', 'dgutierrezu@reuters.com', 'https://infoseek.co.jp', '50.846600', '4.352800', 24, 7, 3, '2015-01-13 12:39:02', '2015-01-08 08:44:03', NULL),
(32, 'Jayo', 'Donec semper sapien a libero. Nam dui.', '4 Mcbride Center', '7-(060)805-1944', 'ehudsonv@domainmarket.com', 'https://ca.gov', '-10.714840', '25.466740', 94, 2, 2, '2015-01-02 02:45:41', '2015-01-28 04:18:46', NULL),
(33, 'Livetube', 'Proin interdum mauris non ligula pellentesque ultrices.', '3461 Eggendart Avenue', '4-(277)086-3011', 'aalvarezw@house.gov', 'http://wix.com', '-21.183330', '24.883330', 13, 1, 4, '2015-01-29 04:29:47', '2015-01-18 16:30:20', NULL),
(34, 'Browsezoom', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', NULL, '8-(866)841-5868', 'jcolemanx@google.ca', 'https://gizmodo.com', '49.838430', '20.961230', 77, 7, 4, '2015-01-17 09:53:28', '2015-01-19 01:14:53', NULL),
(35, 'Gabtune', 'In congue. Etiam justo. Etiam pretium iaculis justo.', '3452 Graceland Court', '2-(034)611-1240', NULL, 'https://samsung.com', '38.893300', '-77.014600', 63, 7, 5, '2015-01-03 01:27:47', '2015-01-04 18:41:56', NULL),
(36, 'Rhynoodle', 'Phasellus sit amet erat. Nulla tempus.', '3 Corscot Place', NULL, 'rgutierrezz@google.com.hk', 'http://jiathis.com', '30.912800', '30.290180', 51, 1, 4, '2015-01-23 19:23:26', '2015-01-08 23:59:52', NULL),
(37, 'Jetwire', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', '579 Raven Point', '2-(490)429-2716', 'nthomas10@wordpress.com', 'http://taobao.com', '-6.495000', '-43.702220', 77, 6, 5, '2015-01-30 15:29:53', '2015-01-05 17:54:57', NULL),
(38, 'Skyvu', NULL, '8581 Lawn Place', '9-(273)194-7905', 'areed11@boston.com', 'http://livejournal.com', '49.565410', '14.990410', 81, 7, 2, '2015-01-20 20:28:57', '2015-01-05 12:22:45', NULL),
(39, 'Wikivu', 'Nullam molestie nibh in lectus.', '7082 Menomonie Lane', '2-(152)130-3147', 'emoore12@xinhuanet.com', 'http://nature.com', '9.562280', '-73.334050', 75, 3, 8, '2015-01-11 13:19:48', '2015-01-16 11:25:55', NULL),
(40, 'Trudoo', 'Suspendisse potenti.', '10661 Hayes Hill', '6-(530)204-7714', 'kperez13@rediff.com', 'http://google.es', '26.425280', '109.229440', 15, 6, 1, '2015-01-16 16:44:33', '2015-01-10 21:42:40', NULL),
(41, 'Livefish', 'Donec dapibus. Duis at velit eu est congue elementum.', '1703 Reindahl Lane', '9-(131)826-1992', 'jhicks14@purevolume.com', 'https://sogou.com', '29.799360', '66.845050', 61, 8, 3, '2015-01-18 10:59:41', '2015-01-04 16:11:45', NULL),
(42, 'Camimbo', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', NULL, '0-(071)897-9509', 'rbennett15@biblegateway.com', 'https://bloomberg.com', '26.104260', '34.277930', 43, 8, 1, '2015-01-07 00:12:15', '2015-01-23 20:30:32', NULL),
(43, 'Zoombeat', 'Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', '43 Steensland Crossing', NULL, 'etucker16@earthlink.net', 'https://army.mil', '5.494620', '-4.051830', 62, 5, 4, '2015-01-17 07:05:53', '2015-01-28 04:55:58', NULL),
(44, 'Pixope', 'Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', '4 Hansons Alley', '9-(465)171-5542', 'afox17@mtv.com', NULL, '-37.545760', '-62.767230', 29, 2, 7, '2015-01-27 23:39:59', '2015-01-25 03:29:10', NULL),
(45, 'Realcube', NULL, '62103 Sycamore Place', '0-(410)433-1734', 'alewis18@bluehost.com', 'https://google.com.hk', '42.050000', '25.600000', 1, 4, 4, '2015-01-23 02:46:55', '2015-01-06 01:52:14', NULL),
(46, 'Skippad', 'Etiam justo.', '56 Dakota Plaza', '5-(946)810-3032', 'rortiz19@blogger.com', 'https://msu.edu', '40.434400', '-80.024800', 83, 1, 8, '2015-01-27 07:47:08', '2015-01-05 00:32:25', NULL),
(47, 'Babblestorm', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem.', '987 Gale Way', '4-(761)226-3607', 'asullivan1a@technorati.com', 'https://bing.com', '41.827230', '124.336950', 25, 3, 7, '2015-01-28 12:44:08', '2015-01-20 07:02:48', NULL),
(48, 'Tanoodle', 'Proin interdum mauris non ligula pellentesque ultrices.', NULL, '7-(361)156-6858', 'aross1b@goodreads.com', 'http://ox.ac.uk', '36.097550', '107.778390', 38, 1, 6, '2015-01-07 02:29:12', '2015-01-20 12:00:37', NULL),
(49, 'Fivechat', 'Nulla suscipit ligula in lacus. Curabitur at ipsum ac tellus semper interdum. Mauris ullamcorper purus sit amet nulla.', '178 8th Alley', '2-(998)295-9019', 'chunter1c@telegraph.co.uk', NULL, '36.563320', '53.060090', 1, 8, 6, '2015-01-08 16:22:49', '2015-01-19 20:52:09', NULL),
(50, 'Rhycero', 'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus.', NULL, '5-(220)182-7507', 'speters1d@wisc.edu', 'http://flickr.com', '43.203890', '140.770280', 92, 3, 3, '2015-01-10 11:59:50', '2015-01-26 20:33:20', NULL),
(51, 'Gabtune', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum.', '5 Heffernan Terrace', '7-(350)344-0121', 'amills1e@icq.com', 'https://cnn.com', '41.000000', '-7.633300', 24, 1, 3, '2015-01-23 17:33:59', '2015-01-30 07:00:20', NULL),
(52, 'Fadeo', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', '78 East Pass', '8-(785)614-5482', NULL, 'http://bbb.org', '38.566700', '-8.883300', 15, 3, 5, '2015-01-15 13:05:28', '2015-01-19 10:08:37', NULL),
(53, 'Bubbletube', 'Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', '5 Kedzie Road', '0-(009)047-5294', 'kedwards1g@state.tx.us', 'https://diigo.com', '43.459900', '-116.244000', 85, 6, 7, '2015-01-28 20:38:59', '2015-01-30 23:31:26', NULL),
(54, 'Midel', 'Ut tellus. Nulla ut erat id mauris vulputate elementum.', '86 Monica Place', NULL, 'delliott1h@bloglines.com', 'http://facebook.com', '-8.338100', '123.098000', 39, 5, 4, '2015-01-04 16:55:06', '2015-01-27 12:46:56', NULL),
(55, 'Skyvu', 'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.', '874 Gina Hill', '6-(355)722-7817', NULL, NULL, '48.557810', '24.756220', 7, 3, 5, '2015-01-26 05:16:28', '2015-01-13 02:41:21', NULL),
(56, 'Edgewire', 'Donec dapibus.', '8415 Nancy Alley', '2-(921)517-6550', 'skim1j@wp.com', 'https://vimeo.com', '31.712400', '118.649240', 37, 8, 6, '2015-01-04 16:30:38', '2015-01-23 16:33:12', NULL),
(57, 'Feednation', 'Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', NULL, NULL, 'jthompson1k@studiopress.com', 'https://imgur.com', '38.783920', '63.880350', 42, 8, 3, '2015-01-02 07:54:40', '2015-01-24 15:10:18', NULL),
(58, 'Tagfeed', 'Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', '79 Di Loreto Avenue', '2-(096)174-9847', 'bjacobs1l@newyorker.com', 'https://chicagotribune.com', '38.190500', '-8.020200', 92, 2, 8, '2015-01-10 04:49:19', '2015-01-09 22:54:33', NULL),
(59, 'Ozu', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', '10 Sutteridge Circle', '7-(907)594-2525', NULL, 'http://eepurl.com', '49.521430', '22.936700', 16, 7, 8, '2015-01-29 00:39:51', '2015-01-30 03:10:49', NULL),
(60, 'Browseblab', 'Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', '89 Arizona Crossing', '6-(280)284-1594', 'criley1n@wsj.com', 'https://constantcontact.com', '6.815000', '124.858610', 31, 5, 5, '2015-01-29 01:16:52', '2015-01-17 22:24:39', NULL),
(61, 'Demimbu', 'Nulla nisl. Nunc nisl. Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa.', '85 Forest Dale Pass', '2-(569)459-7788', 'jmitchell1o@facebook.com', NULL, '49.038900', '2.077000', 44, 3, 6, '2015-01-08 03:13:30', '2015-01-01 00:15:07', NULL),
(62, 'Mydo', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.', '976 Coleman Terrace', '5-(463)224-6036', 'phicks1p@phoca.cz', 'https://census.gov', '36.043060', '14.217220', 85, 6, 4, '2015-01-31 01:33:19', '2015-01-20 03:33:18', NULL),
(63, 'Bubblebox', NULL, '222 Manley Park', '9-(025)684-1029', NULL, 'https://desdev.cn', '41.150000', '-7.933300', 95, 1, 4, '2015-01-31 18:12:29', '2015-01-24 18:03:35', NULL),
(64, 'Topicshots', NULL, NULL, '6-(270)000-9322', 'ejordan1r@delicious.com', 'http://prweb.com', '21.016670', '107.300000', 26, 1, 1, '2015-01-31 16:35:24', '2015-01-10 06:10:19', NULL),
(65, 'Roombo', 'Integer a nibh.', '7 Hollow Ridge Avenue', '0-(719)419-4631', 'jreid1s@hao123.com', NULL, '-7.099200', '108.587400', 38, 3, 2, '2015-01-16 00:16:56', '2015-01-29 15:08:36', NULL),
(66, 'Skippad', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis', '875 Marquette Place', '3-(081)352-8602', 'blynch1t@amazon.co.jp', 'https://cnbc.com', '40.728610', '124.784720', 89, 8, 7, '2015-01-05 14:13:16', '2015-01-08 17:03:43', NULL),
(67, 'Eimbee', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor.', '80 Quincy Lane', '9-(781)391-4277', 'plee1u@wiley.com', 'http://feedburner.com', '-8.406800', '113.740600', 62, 7, 1, '2015-01-21 04:24:55', '2015-01-11 12:42:57', NULL),
(68, 'Topiclounge', 'Ut tellus. Nulla ut erat id mauris vulputate elementum.', NULL, '6-(848)233-3532', 'eharrison1v@dion.ne.jp', 'http://yahoo.com', '48.144610', '-80.037670', 64, 7, 6, '2015-01-19 14:04:38', '2015-01-10 22:53:24', NULL),
(69, 'Meezzy', 'Etiam faucibus cursus urna.', '324 Bartillon Hill', NULL, 'wlarson1w@dot.gov', 'http://businesswire.com', '40.016040', '44.518890', 21, 2, 8, '2015-01-12 13:10:16', '2015-01-04 20:32:05', NULL),
(70, 'Centidel', 'Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem. Sed sagittis.', '3147 Graedel Drive', '6-(334)212-7727', 'mwood1x@imdb.com', 'http://ezinearticles.com', '25.182510', '44.599640', 80, 1, 8, '2015-01-28 10:36:19', '2015-01-06 06:06:00', NULL),
(71, 'Npath', 'Morbi a ipsum. Integer a nibh. In quis justo.', '98 Novick Court', '3-(803)590-1701', 'bmoore1y@canalblog.com', 'http://sogou.com', '-26.230000', '-51.086390', 77, 1, 1, '2015-01-14 03:39:41', '2015-01-13 10:50:46', NULL),
(72, 'Edgeify', 'Morbi non quam nec dui luctus rutrum.', '1330 Texas Drive', '8-(954)536-1972', 'mshaw1z@opera.com', 'http://twitpic.com', '-8.518610', '127.002500', 85, 4, 6, '2015-01-14 04:33:18', '2015-01-28 00:08:53', NULL),
(73, 'Bluezoom', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis.', '3730 Canary Park', '4-(631)259-4168', 'cwilliamson20@1688.com', 'https://symantec.com', '29.896150', '69.251990', 67, 5, 4, '2015-01-23 05:34:17', '2015-01-27 05:35:24', NULL),
(74, 'Wordtune', NULL, '46 Dawn Point', '8-(991)946-2753', 'egilbert21@123-reg.co.uk', NULL, '40.587790', '23.031500', 66, 7, 2, '2015-01-31 05:12:28', '2015-01-20 03:14:04', NULL),
(75, 'Tagcat', 'Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti.', '50 Graceland Court', '9-(321)108-8367', 'jnguyen22@4shared.com', 'https://sbwire.com', '10.232930', '-75.189850', 13, 4, 2, '2015-01-13 05:11:22', '2015-01-23 08:56:23', NULL),
(76, 'Avamba', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', '98269 Reinke Pass', '7-(380)102-5395', 'ajenkins23@omniture.com', 'http://usnews.com', '27.717220', '109.185280', 51, 1, 5, '2015-01-31 14:52:03', '2015-01-02 07:55:55', NULL),
(77, 'Skyble', NULL, '7094 Forest Dale Center', '7-(398)752-4222', 'acastillo24@bigcartel.com', NULL, '49.874780', '20.037090', 49, 2, 4, '2015-01-31 18:04:47', '2015-01-28 05:25:29', NULL),
(78, 'Flashset', 'Phasellus sit amet erat. Nulla tempus.', '215 Mayer Hill', '3-(359)981-4884', 'mkelley25@blogger.com', 'https://studiopress.com', '9.811350', '-83.703360', 38, 3, 8, '2015-01-27 10:58:09', '2015-01-01 16:49:13', NULL),
(79, 'BlogXS', 'In congue. Etiam justo.', '95685 Continental Court', '0-(472)643-8443', 'jwillis26@odnoklassniki.ru', NULL, '47.366700', '-1.166700', 62, 4, 2, '2015-01-28 20:14:29', '2015-01-18 21:48:55', NULL),
(80, 'Chatterbridge', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros.', '089 Stang Way', '9-(721)061-4042', NULL, 'https://wix.com', '-7.099200', '108.587400', 64, 5, 5, '2015-01-24 17:53:12', '2015-01-31 03:44:59', NULL),
(81, 'Quatz', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', '6 Sunnyside Court', '7-(198)621-5613', 'dmedina28@google.co.jp', 'http://stumbleupon.com', '52.508300', '5.475000', 51, 6, 1, '2015-01-07 03:22:23', '2015-01-01 23:39:41', NULL),
(82, 'Blogspan', 'Aliquam erat volutpat.', '399 7th Way', '7-(733)261-3657', 'lgonzalez29@netlog.com', 'https://a8.net', '48.849690', '123.801700', 36, 5, 2, '2015-01-22 06:37:37', '2015-01-30 02:37:59', NULL),
(83, 'Eire', NULL, NULL, '0-(301)496-2439', 'sholmes2a@t.co', NULL, '-18.473330', '-47.200280', 91, 7, 7, '2015-01-26 21:09:52', '2015-01-25 15:21:01', NULL),
(84, 'Realblab', 'Nulla ut erat id mauris vulputate elementum.', '2 Hudson Lane', '1-(420)220-2925', 'rfernandez2b@latimes.com', 'https://dailymotion.com', '41.233300', '-8.016700', 35, 1, 6, '2015-01-29 10:25:51', '2015-01-30 07:23:25', NULL),
(85, 'Skyndu', 'In est risus, auctor sed, tristique in, tempus sit amet, sem. Fusce consequat. Nulla nisl.', '97 Miller Drive', NULL, 'wgardner2c@unesco.org', 'https://miitbeian.gov.cn', '-6.888200', '113.654100', 36, 4, 4, '2014-12-31 23:47:19', '2015-01-13 03:17:53', NULL),
(86, 'Buzzdog', 'Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', '948 Duke Park', '8-(477)177-1338', 'jharrison2d@yellowpages.com', 'http://t.co', '31.803890', '112.152220', 64, 8, 4, '2015-01-19 22:47:02', '2015-01-12 12:52:55', NULL),
(87, 'Wikizz', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.', '21 3rd Place', '7-(020)907-9633', 'jrobinson2e@about.me', 'https://printfriendly.com', '40.740900', '24.577870', 90, 6, 6, '2015-01-13 23:43:43', '2015-01-03 17:59:05', NULL),
(88, 'Eare', 'Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', '1391 Maple Point', '6-(968)393-3745', NULL, 'http://desdev.cn', '48.833300', '2.250000', 54, 7, 3, '2015-01-08 14:48:19', '2015-01-22 00:38:03', NULL),
(89, 'Youtags', 'Phasellus in felis.', '81 Lake View Trail', '4-(677)647-1327', 'jgarrett2g@intel.com', 'https://multiply.com', '47.100000', '5.500000', 64, 2, 7, '2015-01-24 09:45:57', '2015-01-02 00:20:41', NULL),
(90, 'Kamba', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', '966 Magdeline Park', '7-(781)577-1567', 'mwarren2h@yandex.ru', 'https://kickstarter.com', '-7.050500', '108.187700', 78, 8, 7, '2015-01-26 01:33:18', '2015-01-13 07:09:29', NULL),
(91, 'Avavee', 'Praesent blandit.', '899 Clyde Gallagher Plaza', '7-(983)740-0174', 'dcarpenter2i@mayoclinic.com', 'http://japanpost.jp', '44.361210', '77.976440', 93, 6, 2, '2015-01-19 03:01:02', '2015-01-15 16:42:24', NULL),
(92, 'Dynazzy', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna.', '1157 Oak Plaza', NULL, 'nsimpson2j@edublogs.org', NULL, '29.815230', '107.294960', 58, 8, 3, '2015-01-22 06:14:25', '2015-01-03 23:53:42', NULL),
(93, 'Meezzy', 'Quisque porta volutpat erat.', '96 Sauthoff Parkway', '0-(329)773-5202', 'mpatterson2k@nyu.edu', 'http://posterous.com', '17.088820', '103.818750', 61, 3, 7, '2015-01-26 07:36:05', '2015-01-29 02:56:12', NULL),
(94, 'Quatz', 'Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede. Morbi porttitor lorem id ligula.', '8 Maryland Junction', NULL, NULL, 'http://a8.net', '8.008610', '-62.398890', 87, 4, 7, '2015-01-17 00:00:36', '2015-01-07 16:19:32', NULL),
(95, 'Livefish', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', '61693 John Wall Way', '9-(121)248-1544', 'dharper2m@mac.com', 'https://si.edu', '41.021300', '-7.691800', 7, 8, 4, '2015-01-05 15:24:20', '2015-01-09 09:36:16', NULL),
(96, 'Dabtype', 'Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue.', '1929 Prentice Pass', '1-(185)376-0557', 'tlong2n@tamu.edu', 'http://canalblog.com', '51.872500', '4.602800', 58, 1, 4, '2015-01-01 22:22:41', '2015-01-29 10:59:18', NULL),
(97, 'Eidel', NULL, NULL, '1-(138)352-1153', 'jgonzales2o@pcworld.com', NULL, '18.507460', '122.150350', 6, 3, 8, '2015-01-19 12:36:57', '2015-01-09 21:22:12', NULL),
(98, 'Linkbridge', 'In eleifend quam a odio. In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt.', '8524 Upham Pass', '2-(191)230-6405', 'creid2p@dot.gov', 'https://si.edu', '31.300820', '109.560350', 93, 5, 1, '2015-01-13 22:00:04', '2015-01-05 19:46:46', NULL),
(99, 'Eare', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', '10 Corry Pass', '6-(154)275-3014', 'rsimpson2q@multiply.com', 'http://moonfruit.com', '26.604440', '110.985280', 36, 3, 7, '2015-01-26 13:32:58', '2015-01-10 14:43:08', NULL),
(100, 'Fadeo', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', '3958 Ilene Avenue', '0-(790)558-2378', 'jallen2r@wikimedia.org', NULL, '57.670520', '63.071000', 61, 7, 2, '2015-01-20 14:59:27', '2015-01-07 06:07:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `place_types`
--

CREATE TABLE IF NOT EXISTS `place_types` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `place_types`
--

INSERT INTO `place_types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'accounting', '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(2, 'airport', '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(3, 'amusement_park', '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(4, 'aquarium', '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(5, 'art_gallery', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(6, 'atm', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(7, 'bakery', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(8, 'bank', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(9, 'bar', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(10, 'beauty_salon', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(11, 'bicycle_store', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(12, 'book_store', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(13, 'bowling_alley', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(14, 'bus_station', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(15, 'cafe', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(16, 'campground', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(17, 'car_dealer', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(18, 'car_rental', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(19, 'car_repair', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(20, 'car_wash', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(21, 'casino', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(22, 'cemetery', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(23, 'church', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(24, 'city_hall', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(25, 'clothing_store', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(26, 'convenience_stor', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(27, 'courthouse', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(28, 'dentist', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(29, 'department_store', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(30, 'doctor', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(31, 'electrician', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(32, 'electronics_stor', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(33, 'embassy', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(34, 'establishment', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(35, 'finance', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(36, 'fire_station', '2015-02-01 10:49:53', '2015-02-01 10:49:53', NULL),
(37, 'florist', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(38, 'food', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(39, 'funeral_home', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(40, 'furniture_store', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(41, 'gas_station', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(42, 'general_contract', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(43, 'grocery_or_super', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(44, 'gym', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(45, 'hair_care', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(46, 'hardware_store', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(47, 'health', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(48, 'hindu_temple', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(49, 'home_goods_store', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(50, 'hospital', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(51, 'insurance_agency', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(52, 'jewelry_store', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(53, 'laundry', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(54, 'lawyer', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(55, 'library', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(56, 'liquor_store', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(57, 'local_government', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(58, 'locksmith', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(59, 'lodging', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(60, 'meal_delivery', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(61, 'meal_takeaway', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(62, 'mosque', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(63, 'movie_rental', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(64, 'movie_theater', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(65, 'moving_company', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(66, 'museum', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(67, 'night_club', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(68, 'painter', '2015-02-01 10:49:54', '2015-02-01 10:49:54', NULL),
(69, 'park', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(70, 'parking', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(71, 'pet_store', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(72, 'pharmacy', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(73, 'physiotherapist', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(74, 'place_of_worship', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(75, 'plumber', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(76, 'police', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(77, 'post_office', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(78, 'real_estate_agen', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(79, 'restaurant', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(80, 'roofing_contract', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(81, 'rv_park', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(82, 'school', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(83, 'shoe_store', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(84, 'shopping_mall', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(85, 'spa', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(86, 'stadium', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(87, 'storage', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(88, 'store', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(89, 'subway_station', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(90, 'synagogue', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(91, 'taxi_stand', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(92, 'train_station', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(93, 'travel_agency', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(94, 'university', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(95, 'veterinary_care', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL),
(96, 'zoo', '2015-02-01 10:49:55', '2015-02-01 10:49:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` bigint(20) unsigned NOT NULL,
  `username` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `group_id`, `active`, `remember_token`, `last_seen`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'admin', '$2y$10$646JUkJz1DqH/Hnc6Y.HnOeA9ei68FroyiFP1YfMv/uQllD9hcZIu', NULL, NULL, 'admin@guideme.ba', 1, 1, NULL, '2015-02-01 10:51:24', '2015-02-01 10:49:51', '2015-02-01 10:51:24', NULL),
(2, 'tvolaric', '$2y$10$HK/DlQ23dmppHVJAgUotT.OkhBS11soL0PdTkls7R8IkWTUtsSev.', 'Tomislav', 'Volarić', 'tvolaric@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:51', '2015-02-01 10:49:51', NULL),
(3, 'dvasic', '$2y$10$uFKYq5SGzp6zW1Fi.27LZOem3ZP11lkIWSKopvQz8JBc3CHz9rgq2', 'Daniel', 'Vasić', 'dvasic@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(4, 'ebrajkovic', '$2y$10$gTw3NbB0alIzRSlPZIo8T.3dyyo7Zal1.NTpm4p2n0WaA3xl8PT.i', 'Emil', 'Brajković', 'ebrajkovic@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(5, 'adilber', '$2y$10$q4tnTupHEhBLukwpKksBEeN4FrQPqk8QyUcrFyerK/LnzEtMdqcUK', 'Ante', 'Dilber', 'adilber@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(6, 'hljubic', '$2y$10$CpKTcsqgzOwEZA.KMko/DuS4wcZFGb1mri1MvsM3FjgFpnYPgiy62', 'Hrvoje', 'Ljubić', 'hljubic@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(7, 'iprskalo', '$2y$10$RMfFhCo/12tBOrCS6064QusTFV.oL7D.WZFKof/dxzQ.gYDBRtAUq', 'Ivo', 'Prskalo', 'iprskalo@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL),
(8, 'tkordic', '$2y$10$xEtuJklOvKthAk6ITBAx0esAe3Uwsk/3FzPtrdMJ3WTJUmng3vOIG', 'Tomislav', 'Kordić', 'tkordic@guideme.ba', 2, 1, NULL, NULL, '2015-02-01 10:49:52', '2015-02-01 10:49:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
`id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `filename`, `title`, `description`, `place_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'ultrices_mattis_odio.avi', 'Phasellus sit amet erat.', 'Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 70, 3, 6, '2015-01-16 19:09:39', '2015-01-26 04:06:41', NULL),
(2, 'interdum_venenatis.mpeg', 'Nullam varius.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.', 68, 4, 2, '2015-01-08 03:22:42', '2015-01-22 12:59:58', NULL),
(3, 'varius_integer_ac.mp3', 'Suspendisse potenti.', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero. Nullam sit amet turpis elementum ligula vehicula consequat.', 43, 7, 5, '2015-01-21 13:52:34', '2015-01-18 00:13:27', NULL),
(4, 'orci_eget.mp3', 'Duis at velit eu est congue elementum.', 'Suspendisse accumsan tortor quis turpis. Sed ante.', NULL, 3, 5, '2015-01-12 01:24:27', '2015-01-23 13:11:25', NULL),
(5, 'sit_amet.mpeg', 'Donec ut dolor.', NULL, 94, 2, 2, '2015-01-31 20:22:45', '2015-01-21 21:52:45', NULL),
(6, 'et_eros_vestibulum.avi', 'Maecenas ut massa quis augue luctus tincidunt.', 'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', 71, 1, 4, '2015-01-26 22:03:24', '2015-01-23 02:08:39', NULL),
(7, 'enim_blandit_mi.avi', 'Nam dui.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 53, 3, 4, '2015-01-29 05:14:04', '2015-01-15 05:57:32', NULL),
(8, 'nulla_quisque.avi', 'Curabitur convallis.', 'Vestibulum sed magna at nunc commodo placerat. Praesent blandit.', 40, 7, 3, '2015-01-12 09:22:38', '2015-01-24 19:58:11', NULL),
(9, 'eget_tempus.mpeg', 'Aenean fermentum.', 'Donec dapibus.', 6, 1, 3, '2015-01-10 15:25:40', '2015-01-06 21:42:12', NULL),
(10, 'nulla_mollis_molestie.mp3', 'Pellentesque viverra pede ac diam.', 'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 1, 7, 8, '2015-01-23 05:50:11', '2015-01-11 21:47:54', NULL),
(11, 'eget_tincidunt.avi', 'Sed sagittis.', 'Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 69, 4, 8, '2015-01-13 00:34:35', '2015-01-14 11:25:28', NULL),
(12, 'cursus_id_turpis.mpeg', 'In congue.', 'Morbi non quam nec dui luctus rutrum. Nulla tellus. In sagittis dui vel nisl.', 5, 6, 3, '2015-01-12 13:39:50', '2015-01-15 23:33:15', NULL),
(13, 'faucibus.mp3', 'Duis consequat dui nec nisi volutpat eleifend.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 75, 5, 5, '2015-01-02 14:50:27', '2015-01-27 12:57:14', NULL),
(14, 'cursus_id_turpis.avi', 'Maecenas pulvinar lobortis est.', 'Curabitur at ipsum ac tellus semper interdum. Mauris ullamcorper purus sit amet nulla.', 69, 3, 4, '2015-01-30 20:26:48', '2015-01-09 10:59:15', NULL),
(15, 'at_diam_nam.avi', 'Sed vel enim sit amet nunc viverra dapibus.', 'Nullam molestie nibh in lectus. Pellentesque at nulla. Suspendisse potenti.', 48, 3, 3, '2015-01-10 20:52:08', '2015-01-16 02:16:17', NULL),
(16, 'blandit_lacinia.mp3', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'Phasellus in felis. Donec semper sapien a libero. Nam dui.', 97, 4, 8, '2015-01-15 19:25:32', '2015-01-11 17:53:14', NULL),
(17, 'suspendisse_potenti_in.avi', 'In sagittis dui vel nisl.', 'Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat. Praesent blandit.', 82, 2, 1, '2015-01-07 07:41:51', '2015-01-27 12:50:12', NULL),
(18, 'ac_leo.mp3', 'Duis at velit eu est congue elementum.', 'Nam nulla.', 31, 1, 5, '2015-01-02 18:43:05', '2015-01-24 04:35:53', NULL),
(19, 'sit_amet_consectetuer.mpeg', 'Aenean lectus.', 'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', NULL, 8, 7, '2015-01-19 06:09:46', '2015-01-10 08:16:58', NULL),
(20, 'phasellus_id_sapien.avi', 'Duis consequat dui nec nisi volutpat eleifend.', 'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.', 93, 1, 3, '2015-01-22 02:47:19', '2015-01-23 07:05:35', NULL),
(21, 'luctus_tincidunt_nulla.mp3', 'In blandit ultrices enim.', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 41, 8, 8, '2015-01-13 16:26:57', '2015-01-05 18:22:46', NULL),
(22, 'mi_integer.avi', 'Aliquam quis turpis eget elit sodales scelerisque.', 'Morbi porttitor lorem id ligula.', 66, 7, 8, '2015-01-25 05:57:57', '2015-01-18 15:02:13', NULL),
(23, 'scelerisque.mp3', 'Sed ante.', 'Praesent lectus.', 77, 4, 8, '2015-01-07 20:27:39', '2015-01-05 05:58:52', NULL),
(24, 'integer.mp3', 'Nulla ut erat id mauris vulputate elementum.', 'Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.', 22, 7, 6, '2015-01-16 05:13:19', '2015-01-09 17:14:17', NULL),
(25, 'commodo_vulputate.mpeg', 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'Nunc rhoncus dui vel sem. Sed sagittis.', 2, 5, 7, '2015-01-05 09:33:58', '2015-01-09 07:44:47', NULL),
(26, 'vulputate_justo.mp3', 'Aenean fermentum.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus.', 1, 4, 6, '2015-01-08 04:26:48', '2015-01-25 18:29:15', NULL),
(27, 'proin.avi', 'Maecenas tincidunt lacus at velit.', 'Nam dui. Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 12, 6, 3, '2015-01-26 21:32:15', '2015-01-02 08:51:17', NULL),
(28, 'sapien.avi', 'Nulla justo.', 'Nulla tellus. In sagittis dui vel nisl. Duis ac nibh.', NULL, 3, 7, '2015-01-24 08:59:48', '2015-01-10 23:14:29', NULL),
(29, 'semper_porta_volutpat.mp3', 'Aenean auctor gravida sem.', 'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo.', 58, 2, 7, '2015-01-23 10:40:38', '2015-01-18 09:29:27', NULL),
(30, 'pede_ac_diam.mp3', 'Vivamus vel nulla eget eros elementum pellentesque.', 'In congue. Etiam justo. Etiam pretium iaculis justo.', 87, 5, 3, '2015-01-16 19:26:34', '2015-01-07 10:39:58', NULL),
(31, 'cras.mp3', 'Suspendisse potenti.', 'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 10, 5, 2, '2015-01-25 11:53:00', '2015-01-18 12:17:55', NULL),
(32, 'platea.avi', 'Sed sagittis.', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 78, 6, 2, '2015-01-05 16:50:33', '2015-01-16 10:45:07', NULL),
(33, 'elit.mov', 'Nulla mollis molestie lorem.', 'In hac habitasse platea dictumst.', 4, 5, 3, '2015-01-01 12:19:14', '2015-01-24 07:08:12', NULL),
(34, 'sit_amet.avi', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 67, 7, 7, '2015-01-24 04:28:21', '2015-01-02 17:29:28', NULL),
(35, 'non_interdum.mov', 'Morbi a ipsum.', 'Nunc purus. Phasellus in felis.', 41, 6, 8, '2015-01-17 13:16:05', '2015-01-16 17:04:06', NULL),
(36, 'vestibulum_ante.mov', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', NULL, 76, 3, 1, '2015-01-12 20:06:15', '2015-01-11 13:43:09', NULL),
(37, 'integer.mpeg', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus. Phasellus in felis.', 36, 7, 3, '2015-01-22 17:27:47', '2015-01-19 12:11:23', NULL),
(38, 'praesent_id_massa.mp3', 'Cras in purus eu magna vulputate luctus.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien.', 25, 3, 7, '2015-01-01 03:30:08', '2015-01-19 20:10:08', NULL),
(39, 'adipiscing_molestie.avi', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Nulla suscipit ligula in lacus.', NULL, 5, 7, '2015-01-06 23:36:44', '2015-01-09 23:37:08', NULL),
(40, 'sed_tristique.avi', 'Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', 99, 4, 4, '2015-01-27 22:56:52', '2015-01-13 03:30:28', NULL),
(41, 'varius_nulla_facilisi.mpeg', 'Donec ut dolor.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.', 71, 8, 4, '2015-01-19 03:30:53', '2015-01-18 03:40:53', NULL),
(42, 'at_ipsum_ac.mp3', 'In congue.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 22, 2, 8, '2015-01-08 18:12:07', '2015-01-09 19:56:51', NULL),
(43, 'sollicitudin.avi', 'Pellentesque viverra pede ac diam.', 'Curabitur at ipsum ac tellus semper interdum. Mauris ullamcorper purus sit amet nulla.', 9, 8, 5, '2015-01-05 04:46:47', '2015-01-06 21:18:56', NULL),
(44, 'rutrum.avi', 'Aliquam non mauris.', 'Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius.', 90, 8, 4, '2015-01-01 20:13:58', '2015-01-20 03:28:16', NULL),
(45, 'magna_at_nunc.mp3', 'Vivamus in felis eu sapien cursus vestibulum.', 'Ut at dolor quis odio consequat varius. Integer ac leo.', 85, 6, 7, '2015-01-21 01:25:13', '2015-01-08 03:42:06', NULL),
(46, 'ultrices_posuere_cubilia.avi', 'Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', 'Nunc rhoncus dui vel sem. Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 54, 6, 3, '2015-01-24 21:02:54', '2015-01-11 07:23:28', NULL),
(47, 'nam_ultrices.mp3', 'Maecenas pulvinar lobortis est.', 'Quisque ut erat. Curabitur gravida nisi at nibh. In hac habitasse platea dictumst.', NULL, 3, 6, '2015-01-23 21:59:15', '2015-01-22 15:19:20', NULL),
(48, 'velit_id_pretium.mp3', 'Aliquam sit amet diam in magna bibendum imperdiet.', 'Donec dapibus. Duis at velit eu est congue elementum. In hac habitasse platea dictumst.', 68, 5, 7, '2015-01-17 04:32:38', '2015-01-08 14:09:28', NULL),
(49, 'nam_nulla_integer.mpeg', 'Aenean auctor gravida sem.', 'Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 80, 8, 7, '2015-01-04 09:19:58', '2015-01-17 02:30:35', NULL),
(50, 'varius_integer.mp3', 'Pellentesque ultrices mattis odio.', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus. Pellentesque at nulla.', 93, 5, 3, '2015-01-18 07:33:26', '2015-01-22 01:18:17', NULL),
(51, 'vitae_ipsum_aliquam.mp3', 'Aliquam non mauris.', 'Nam tristique tortor eu pede.', 10, 4, 1, '2015-01-10 15:11:49', '2015-01-14 04:49:59', NULL),
(52, 'ipsum_aliquam.mpeg', 'Fusce consequat.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 62, 1, 2, '2015-01-19 03:43:09', '2015-01-24 23:59:22', NULL),
(53, 'neque.mp3', 'Phasellus id sapien in sapien iaculis congue.', 'Nam dui. Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 88, 6, 1, '2015-01-01 02:57:20', '2015-01-01 22:07:49', NULL),
(54, 'mauris_vulputate.mp3', 'Aenean auctor gravida sem.', NULL, 14, 4, 7, '2015-01-09 21:51:23', '2015-01-19 23:58:13', NULL),
(55, 'duis_consequat.mpeg', 'Etiam faucibus cursus urna.', NULL, 88, 1, 2, '2015-01-05 11:21:36', '2015-01-16 08:20:40', NULL),
(56, 'interdum_venenatis.avi', 'Duis mattis egestas metus.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien.', 81, 7, 7, '2015-01-29 17:39:46', '2015-01-28 20:46:40', NULL),
(57, 'nec_sem_duis.avi', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla.', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 80, 8, 8, '2015-01-01 10:30:43', '2015-01-21 19:30:24', NULL),
(58, 'convallis_nunc.avi', 'Nam nulla.', 'In quis justo. Maecenas rhoncus aliquam lacus.', 2, 5, 2, '2015-01-02 07:01:21', '2015-01-09 23:33:37', NULL),
(59, 'phasellus_id_sapien.mp3', 'Donec semper sapien a libero.', 'Nullam varius. Nulla facilisi.', 13, 5, 2, '2015-01-11 14:14:06', '2015-01-16 11:31:31', NULL),
(60, 'porta.avi', 'Morbi porttitor lorem id ligula.', 'Nunc purus. Phasellus in felis.', 1, 3, 8, '2015-01-22 19:25:36', '2015-01-13 20:02:54', NULL),
(61, 'cras.mov', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Nunc nisl.', 62, 5, 2, '2015-01-07 07:55:45', '2015-01-08 04:55:48', NULL),
(62, 'amet_cursus_id.mp3', 'Duis consequat dui nec nisi volutpat eleifend.', 'Morbi non lectus.', 8, 2, 2, '2015-01-16 06:23:12', '2015-01-27 22:47:11', NULL),
(63, 'lectus_pellentesque.avi', 'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 'Morbi vel lectus in quam fringilla rhoncus. Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 5, 5, 8, '2015-01-21 14:09:06', '2015-01-04 02:15:05', NULL),
(64, 'consequat.avi', 'Donec dapibus.', NULL, NULL, 8, 4, '2015-01-16 18:42:08', '2015-01-26 05:08:40', NULL),
(65, 'ac_tellus_semper.mp3', 'Curabitur in libero ut massa volutpat convallis.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 23, 5, 5, '2015-01-24 01:13:25', '2015-01-28 23:58:04', NULL),
(66, 'eu_interdum.avi', 'Curabitur in libero ut massa volutpat convallis.', 'In est risus, auctor sed, tristique in, tempus sit amet, sem. Fusce consequat. Nulla nisl.', 16, 5, 6, '2015-01-14 11:20:47', '2015-01-06 04:06:05', NULL),
(67, 'odio_in_hac.mov', 'Pellentesque ultrices mattis odio.', 'Aenean lectus.', NULL, 1, 1, '2015-01-30 08:06:19', '2015-01-09 11:44:29', NULL),
(68, 'ipsum.mov', 'Phasellus id sapien in sapien iaculis congue.', 'Donec ut dolor.', 72, 1, 6, '2015-01-16 03:37:00', '2015-01-25 22:43:42', NULL),
(69, 'consequat_in_consequat.avi', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi.', 'Suspendisse potenti. In eleifend quam a odio.', 51, 2, 1, '2015-01-13 02:32:47', '2015-01-23 21:23:29', NULL),
(70, 'dictumst_morbi_vestibulum.mp3', 'In hac habitasse platea dictumst.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 55, 8, 7, '2015-01-05 06:56:26', '2015-01-16 21:03:48', NULL),
(71, 'duis_bibendum.avi', 'Proin eu mi.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus.', NULL, 2, 1, '2015-01-16 16:12:55', '2015-01-26 12:42:46', NULL),
(72, 'habitasse_platea.avi', 'Duis mattis egestas metus.', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 99, 4, 3, '2015-01-04 01:06:28', '2015-01-11 10:09:10', NULL),
(73, 'congue_vivamus_metus.mpeg', 'Phasellus id sapien in sapien iaculis congue.', 'Proin eu mi. Nulla ac enim.', 46, 2, 8, '2015-01-18 23:17:18', '2015-01-21 10:37:50', NULL),
(74, 'felis.mov', 'Mauris sit amet eros.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', NULL, 7, 8, '2015-01-16 13:49:01', '2015-01-18 19:03:29', NULL),
(75, 'duis.mov', 'Nulla nisl.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 43, 5, 7, '2015-01-25 17:52:45', '2015-01-10 00:31:30', NULL),
(76, 'quam_pede.avi', 'Donec ut mauris eget massa tempor convallis.', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum.', 28, 7, 8, '2015-01-20 07:04:00', '2015-01-01 05:18:58', NULL),
(77, 'dictumst_morbi_vestibulum.mov', 'Praesent blandit lacinia erat.', 'Curabitur convallis. Duis consequat dui nec nisi volutpat eleifend.', 57, 3, 6, '2015-01-31 03:44:17', '2015-01-03 00:05:46', NULL),
(78, 'pellentesque_ultrices.avi', 'Ut at dolor quis odio consequat varius.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', NULL, 2, 7, '2015-01-17 16:22:01', '2015-01-18 01:00:30', NULL),
(79, 'velit_vivamus_vel.mpeg', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Nullam porttitor lacus at turpis.', 21, 1, 1, '2015-01-16 21:43:49', '2015-01-22 05:05:40', NULL),
(80, 'venenatis_tristique.mpeg', 'Nam nulla.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 46, 8, 5, '2015-01-21 14:30:26', '2015-01-05 08:47:06', NULL),
(81, 'vel.mov', 'Integer ac neque.', 'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.', 56, 4, 6, '2015-01-04 21:31:00', '2015-01-02 13:20:24', NULL),
(82, 'ipsum_praesent_blandit.avi', 'Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', NULL, 79, 6, 2, '2015-01-06 13:01:40', '2015-01-04 14:47:27', NULL),
(83, 'dui.mp3', 'In congue.', NULL, 38, 5, 6, '2015-01-28 08:52:19', '2015-01-28 22:51:16', NULL),
(84, 'ultrices.mpeg', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.', 'Curabitur convallis.', 9, 4, 3, '2015-01-21 08:46:51', '2015-01-15 01:56:22', NULL),
(85, 'elementum_in.mp3', 'Suspendisse accumsan tortor quis turpis.', NULL, 55, 5, 2, '2015-01-17 17:57:19', '2015-01-14 14:05:17', NULL),
(86, 'luctus.mp3', 'Fusce consequat.', 'Cras non velit nec nisi vulputate nonummy.', 61, 2, 5, '2015-01-18 05:39:41', '2015-01-23 17:04:03', NULL),
(87, 'quis_turpis_sed.avi', 'Nam nulla.', 'In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin interdum mauris non ligula pellentesque ultrices.', 54, 2, 5, '2015-01-26 02:21:49', '2015-01-25 20:23:16', NULL),
(88, 'in_eleifend_quam.mp3', 'Fusce consequat.', 'Maecenas pulvinar lobortis est.', 71, 6, 2, '2015-01-24 04:11:44', '2015-01-21 03:04:05', NULL),
(89, 'elementum_pellentesque.avi', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', NULL, 44, 3, 1, '2015-01-28 14:11:42', '2015-01-31 11:14:44', NULL),
(90, 'in.mp3', 'Integer non velit.', 'Integer ac neque. Duis bibendum. Morbi non quam nec dui luctus rutrum.', 27, 7, 7, '2015-01-31 14:16:39', '2015-01-12 21:39:29', NULL),
(91, 'tempus_sit.mp3', 'Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 10, 5, 3, '2015-01-20 22:42:04', '2015-01-26 15:28:40', NULL),
(92, 'amet.avi', 'Maecenas rhoncus aliquam lacus.', 'Etiam faucibus cursus urna. Ut tellus.', 77, 1, 1, '2015-01-30 00:24:35', '2015-01-30 09:24:57', NULL),
(93, 'luctus_cum_sociis.mp3', 'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 25, 7, 8, '2015-01-12 10:37:02', '2015-01-06 06:46:42', NULL),
(94, 'tellus.avi', 'Suspendisse potenti.', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 54, 8, 1, '2015-01-22 19:49:07', '2015-01-30 14:36:33', NULL),
(95, 'curae.mp3', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem.', 3, 7, 5, '2015-01-30 16:57:21', '2015-01-08 14:46:36', NULL),
(96, 'a.mp3', 'Cras in purus eu magna vulputate luctus.', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus.', 57, 4, 3, '2015-01-23 15:17:36', '2015-01-16 05:45:42', NULL),
(97, 'fusce_consequat.mov', 'Nunc nisl.', 'Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 66, 8, 3, '2014-12-31 23:22:43', '2015-01-03 11:20:54', NULL),
(98, 'rhoncus.mov', 'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.', 84, 5, 7, '2015-01-21 04:09:23', '2015-01-31 11:28:16', NULL),
(99, 'pulvinar_sed_nisl.mp3', 'Nulla suscipit ligula in lacus.', NULL, 44, 2, 6, '2015-01-21 03:07:14', '2015-01-31 01:01:53', NULL),
(100, 'metus.mpeg', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue.', 36, 6, 5, '2015-01-28 21:53:31', '2015-01-31 08:44:25', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
 ADD PRIMARY KEY (`id`), ADD KEY `articles_place_id_foreign` (`place_id`), ADD KEY `articles_created_by_foreign` (`created_by`), ADD KEY `articles_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `audio_filename_unique` (`filename`), ADD KEY `audio_place_id_foreign` (`place_id`), ADD KEY `audio_created_by_foreign` (`created_by`), ADD KEY `audio_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `images_filename_unique` (`filename`), ADD KEY `images_place_id_foreign` (`place_id`), ADD KEY `images_created_by_foreign` (`created_by`), ADD KEY `images_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
 ADD PRIMARY KEY (`id`), ADD KEY `places_place_type_id_foreign` (`place_type_id`), ADD KEY `places_created_by_foreign` (`created_by`), ADD KEY `places_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `place_types`
--
ALTER TABLE `place_types`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `place_types_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_username_unique` (`username`), ADD UNIQUE KEY `users_email_unique` (`email`), ADD KEY `users_group_id_foreign` (`group_id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `video_filename_unique` (`filename`), ADD KEY `video_place_id_foreign` (`place_id`), ADD KEY `video_created_by_foreign` (`created_by`), ADD KEY `video_updated_by_foreign` (`updated_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `place_types`
--
ALTER TABLE `place_types`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
ADD CONSTRAINT `articles_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
ADD CONSTRAINT `articles_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
ADD CONSTRAINT `articles_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `audio`
--
ALTER TABLE `audio`
ADD CONSTRAINT `audio_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
ADD CONSTRAINT `audio_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
ADD CONSTRAINT `audio_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `images`
--
ALTER TABLE `images`
ADD CONSTRAINT `images_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
ADD CONSTRAINT `images_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
ADD CONSTRAINT `images_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `places`
--
ALTER TABLE `places`
ADD CONSTRAINT `places_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
ADD CONSTRAINT `places_place_type_id_foreign` FOREIGN KEY (`place_type_id`) REFERENCES `place_types` (`id`),
ADD CONSTRAINT `places_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
ADD CONSTRAINT `users_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`);

--
-- Constraints for table `video`
--
ALTER TABLE `video`
ADD CONSTRAINT `video_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
ADD CONSTRAINT `video_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
ADD CONSTRAINT `video_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
